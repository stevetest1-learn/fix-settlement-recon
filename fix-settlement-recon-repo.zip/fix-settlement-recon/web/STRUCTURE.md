# Website structure

Everything under `web/` is the deployable site. It is entirely static — no
backend, no database, no build step beyond generating the wheel and the
sample files.

```
web/
├── index.html                                  the tool
├── fix_settlement_recon-0.1.0-py3-none-any.whl the engine (31 KB)
└── samples/
    ├── manifest.json                           scenario list the page reads
    ├── clean-netted.json                       three fills, one payment
    ├── reverted-payment.json                   mined, gas burned, nothing moved
    ├── decimals-bug.json                       18 decimals assumed, 6 actual
    ├── wrong-recipient.json                    right amount, wrong wallet
    ├── batch-with-stray.json                   two clients, one unexplained leg
    └── not-yet-final.json                      matched, not releasable
```

Regenerate the two build artefacts with:

```bash
python3 -m build --wheel && cp dist/*.whl web/
python3 build_samples.py
```

Upload `web/` to any static host. Directory structure is preserved as-is;
the page loads `./samples/manifest.json` and `./fix_settlement_recon-*.whl`
by relative path, so the whole folder must land together under one prefix.

## What the page shows

Three views, coarse to fine:

**Tally** — matched settlements, critical and warning counts. The number an
ops lead looks at.

**Ledger** — obligations on the left, transfers on the right, curved rails
across the gutter joining them. Three lines converging on one card is a
netting group; that convergence is the thing worth seeing at a glance. Solid
rails are high-confidence matches, dashed are heuristic.

**Field comparison** — the drill-down. Each matched settlement expands into a
row-by-row pairing of FIX tags against chain fields, with four outcomes:

| Status | Meaning |
|---|---|
| `match` | Both sides present and agreeing |
| `break` | Both present, disagreeing — the break lives here |
| `FIX only` | A FIX field with no chain counterpart |
| `chain only` | A chain field with no FIX counterpart |

The asymmetric rows carry as much information as the matched ones. `ExecID`
is FIX-only because the chain has never heard of one — which is precisely why
matching has to be tiered rather than a join. Finality and gas cost are
chain-only because FIX models settlement as an instruction with a date, and
has no way to express "settled, but three confirmations deep."

A comparison is also built for suspected misdirection, where the amount and
window match but the wallet doesn't. That pairing never becomes a match, but
it is exactly the case an analyst needs the field view for.

## Scenarios

`samples/` exists so a visitor sees a real break within one click, without
supplying trade data. Each file is a complete payload — fills, wallet
mappings, receipts — and the manifest carries the title, teaser, and what to
expect.

Adding one means editing `SCENARIOS` in `build_samples.py` and re-running it.
Keep them small: one break each, so the page teaches one thing at a time.

If `samples/` is absent the scenario strip hides itself and the rest of the
page works normally — useful if you want the bare tool without the demo
framing.

## Deployment notes

The page is cheap to cache and the wheel is versioned, so:

- `index.html` — `max-age=300`, invalidate on deploy
- `*.whl` — `max-age=31536000, immutable`, never needs invalidation
- `samples/*.json` — `max-age=3600`

If your host sets a Content-Security-Policy, Pyodide needs
`'wasm-unsafe-eval'` in `script-src` and `worker-src 'self' blob:`. See
`DEPLOY.md` for the full header and the S3/CloudFront commands.
