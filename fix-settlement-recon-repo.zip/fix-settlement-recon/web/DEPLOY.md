# Deploying the break debugger

The tool is **two static files**. There is no backend, no database, and no
account system.

```
index.html                                  # the tool
fix_settlement_recon-0.1.0-py3-none-any.whl # the engine, 31 KB
```

Both go in the same directory of your existing bucket. `index.html` loads
Pyodide from a CDN, installs the wheel from its own origin, and runs the
reconciler in the browser.

## Why static, and not a Lambda

People debugging real breaks will paste execution reports containing live
account IDs, ExecIDs, counterparty wallets and notional amounts. If that
traffic reaches your infrastructure you are holding other firms' production
trade data — in logs, in CloudWatch, in whatever a future misconfiguration
exposes. Several banks would not let staff use the tool at all.

Client-side execution removes the question. Nothing to log, nothing to
breach, nothing to put in a data-processing agreement. It also costs
roughly a dollar a month and scales to any traffic CloudFront can serve.

This only works because the package has zero runtime dependencies. That was
worth protecting for its own sake, and this is the payoff.

## Deploy

```bash
# 1. build the wheel
python3 -m build --wheel

# 2. publish both files under a path on your existing distribution
BUCKET=your-site-bucket
DIST=E1234567890ABC
PREFIX=recon                       # serves at https://yoursite.com/recon/

aws s3 cp web/index.html "s3://$BUCKET/$PREFIX/index.html" \
  --content-type "text/html; charset=utf-8" \
  --cache-control "public, max-age=300"

aws s3 cp dist/fix_settlement_recon-0.1.0-py3-none-any.whl "s3://$BUCKET/$PREFIX/" \
  --content-type "application/octet-stream" \
  --cache-control "public, max-age=31536000, immutable"

aws s3 cp web/index.html "s3://$BUCKET/$PREFIX/index.html" --dryrun >/dev/null

# 3. invalidate the page only; the wheel is versioned, so it never needs it
aws cloudfront create-invalidation --distribution-id "$DIST" --paths "/$PREFIX/index.html"
```

The wheel filename carries its version, so `immutable` is safe and correct.
When you cut `0.2.0`, upload the new wheel, bump the `WHEEL` constant in
`index.html`, and invalidate only the page. Nobody gets a half-updated
cache.

## Terraform

If your bucket and distribution are already managed, this is all that's new:

```hcl
resource "aws_s3_object" "recon_page" {
  bucket        = aws_s3_bucket.site.id
  key           = "recon/index.html"
  source        = "${path.module}/../web/index.html"
  etag          = filemd5("${path.module}/../web/index.html")
  content_type  = "text/html; charset=utf-8"
  cache_control = "public, max-age=300"
}

resource "aws_s3_object" "recon_wheel" {
  bucket        = aws_s3_bucket.site.id
  key           = "recon/fix_settlement_recon-0.1.0-py3-none-any.whl"
  source        = "${path.module}/../dist/fix_settlement_recon-0.1.0-py3-none-any.whl"
  etag          = filemd5("${path.module}/../dist/fix_settlement_recon-0.1.0-py3-none-any.whl")
  content_type  = "application/octet-stream"
  cache_control = "public, max-age=31536000, immutable"
}
```

## The one thing that will break it

**Content-Security-Policy.** If your CloudFront response-headers policy sets
a CSP — and your FIX Parser site probably does — Pyodide will fail to start,
because WebAssembly compilation counts as `eval`. The page will sit on
"Loading Python runtime…" forever and the real reason will only be in the
console.

You need, at minimum:

```
script-src  'self' https://cdn.jsdelivr.net 'wasm-unsafe-eval';
connect-src 'self' https://cdn.jsdelivr.net https://*.g.alchemy.com https://*.infura.io;
worker-src  'self' blob:;
```

`connect-src` has to include whatever RPC endpoints you want people to be
able to reach, since the browser calls them directly. Add hosts as you find
them, or drop the fetch-by-hash panel and accept pasted receipts only.

If you would rather not depend on jsdelivr, mirror Pyodide into your own
bucket (about 10 MB for the core runtime), point the `<script src>` at it,
and drop jsdelivr from the CSP entirely. Slower to set up, one fewer
third party in the trust chain, and it keeps the tool working if jsdelivr
is blocked on a corporate network — which, for this audience, it often is.

## Test locally first

```bash
python3 -m build --wheel
mkdir -p _serve && cp web/index.html dist/*.whl _serve/
cd _serve && python3 -m http.server 8000
# open http://localhost:8000
```

Opening `index.html` from `file://` will not work — `micropip` needs a real
origin to fetch the wheel from.

Click **Load worked example** and reconcile. You should get two matched
settlements, two critical breaks (a reverted payment and an unexplained
outflow), one warning, one informational fee residual, and one message
rejected for sub-cent precision. If you get that, everything is wired up.

## Optional: a shared RPC endpoint

The fetch-by-hash panel asks visitors for their own JSON-RPC URL, stored in
their browser's local storage and never sent anywhere else. For a debugging
tool aimed at engineers this is the right default — they have a key, and it
keeps you out of the loop entirely.

If you want casual visitors to try a live transaction hash without signing
up for Alchemy, put a proxy in front of your own key. Do not just expose the
key in the page; it will be scraped within days and billed to you.

`infra/rpc_proxy.py` is a minimal hardened proxy: it allowlists the five
read-only methods the tool needs, caps `eth_getLogs` block ranges, and logs
nothing but method names. Put it behind API Gateway with a throttle
(20 req/s burst, 5 req/s steady is plenty), keep the key in Secrets Manager,
and point the page's RPC field at it as a default.

Treat this as a later addition. The tool is complete and useful without it,
and every piece of infrastructure you add is another thing that can leak.

## Making it findable

The tool answers a question people actually type into search: why a FIX
settlement doesn't match an on-chain transfer. A few things help more than
they should:

- Give the page its own `<title>` and description mentioning FIX, USDC and
  reconciliation — already set in the file.
- Link it from your FIX Parser page and from your LinkedIn featured section.
- Publish the package to PyPI under `fix-settlement-recon`. You have done
  this before with `fix-venue-profiles`, and a `pip install` that works is
  more persuasive to an engineering interviewer than a screenshot.
- The **Copy break summary** button exists so people can paste a classified
  break into their own notes or an assistant. That is the format your FIX
  Support AI Engine already consumes, which is the connection worth drawing
  when someone asks how the projects fit together.
