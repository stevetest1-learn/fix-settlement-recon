"""
Tests are organised by failure mode, not by function, because the failure
modes are the actual specification. Every one of these is something that
happens in production.
"""

import datetime as dt
from decimal import Decimal

import pytest

from fix_settlement_recon import (
    BreakCode,
    ReconConfig,
    SettlementState,
    StaticWalletDirectory,
    TokenAmount,
    decode_receipt,
    decode_transfer_calldata,
    detect_reorgs,
    obligation_from_execution_report,
    parse_fix,
    reconcile,
)
from fix_settlement_recon.chains import ETHEREUM
from fix_settlement_recon.keccak import (
    event_topic,
    function_selector,
    keccak256,
    to_checksum_address,
)
from fix_settlement_recon.models import PrecisionError

USDC = "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
VENUE = "0x1111111111111111111111111111111111111111"
CLIENT = "0x2222222222222222222222222222222222222222"
STRANGER = "0x3333333333333333333333333333333333333333"

TRANSFER_TOPIC = event_topic("Transfer(address,address,uint256)")


def topic_addr(a):
    return "0x" + a.removeprefix("0x").rjust(64, "0")


def make_receipt(amount_minor, *, recipient=CLIENT, status="0x1", block=100,
                 token=USDC, extra_legs=(), block_hash="0xaaa"):
    logs = [{
        "address": token,
        "topics": [TRANSFER_TOPIC, topic_addr(VENUE), topic_addr(recipient)],
        "data": hex(amount_minor),
        "logIndex": "0x0",
    }]
    for i, (recip, amt) in enumerate(extra_legs, start=1):
        logs.append({
            "address": token,
            "topics": [TRANSFER_TOPIC, topic_addr(VENUE), topic_addr(recip)],
            "data": hex(amt),
            "logIndex": hex(i),
        })
    return {
        "transactionHash": "0xdeadbeef",
        "blockNumber": hex(block),
        "blockHash": block_hash,
        "status": status,
        "from": VENUE,
        "to": token,
        "gasUsed": hex(65000),
        "effectiveGasPrice": hex(20_000_000_000),
        "logs": logs,
    }


def exec_report(exec_id, amount, *, account="CLIENT1", settl_date="20260811",
                transact_time="20260811-14:30:00.000", commission=None,
                currency="USD", ref=None, chain=1):
    tags = {
        35: "8", 39: "2", 17: exec_id, 37: "ORD-1", 11: "CL-1",
        1: account, 54: "1", 55: "ETH/USD",
        119: str(amount), 120: currency, 64: settl_date, 60: transact_time,
        20002: str(chain),
    }
    if commission is not None:
        tags[12] = str(commission)
    if ref is not None:
        tags[20003] = ref
    return "\x01".join(f"{k}={v}" for k, v in tags.items())


@pytest.fixture
def directory():
    d = StaticWalletDirectory()
    d.register("CLIENT1", 1, CLIENT)
    d.register("CLIENT2", 1, STRANGER)
    return d


def events_for(receipt, *, confirmations=200, ts=None):
    ts = ts or dt.datetime(2026, 8, 11, 14, 35, tzinfo=dt.timezone.utc)
    block = int(receipt["blockNumber"], 16)
    return decode_receipt(receipt, ts, chain_id=1,
                          current_block=block + confirmations - 1)


# --------------------------------------------------------------------
# primitives
# --------------------------------------------------------------------

def test_keccak_matches_known_vectors():
    assert keccak256(b"").hex() == (
        "c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470"
    )
    assert event_topic("Transfer(address,address,uint256)") == (
        "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
    )
    assert function_selector("transfer(address,uint256)") == "0xa9059cbb"


def test_usdc_address_checksums_correctly():
    assert to_checksum_address(USDC) == "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48"


def test_amounts_are_exact_and_never_float():
    a = TokenAmount.from_decimal_str("8500.00", 6, "USDC")
    assert a.raw == 8_500_000_000
    assert a.decimal == Decimal("8500")
    assert (a + a).raw == 17_000_000_000


def test_sub_minor_unit_precision_is_rejected():
    with pytest.raises(PrecisionError):
        TokenAmount.from_decimal_str("100.0000001", 6, "USDC")


def test_mixing_scales_is_refused():
    with pytest.raises(ValueError):
        TokenAmount(1, 6, "USDC") + TokenAmount(1, 18, "DAI")


# --------------------------------------------------------------------
# decoding
# --------------------------------------------------------------------

def test_recipient_comes_from_calldata_not_the_to_field():
    calldata = ("0xa9059cbb"
                + CLIENT.removeprefix("0x").rjust(64, "0")
                + hex(8_500_000_000)[2:].rjust(64, "0"))
    decoded = decode_transfer_calldata(calldata)
    assert decoded["to"] == CLIENT
    assert decoded["amount"] == 8_500_000_000


def test_decode_extracts_transfer_and_gas():
    ev = events_for(make_receipt(8_500_000_000))[0]
    assert ev.amount.raw == 8_500_000_000
    assert ev.amount.decimal == Decimal("8500")
    assert ev.token_symbol == "USDC"
    assert ev.recipient == CLIENT
    assert ev.gas_cost_wei == 65000 * 20_000_000_000


def test_unknown_token_contract_is_ignored():
    spoof = make_receipt(8_500_000_000, token="0x9999999999999999999999999999999999999999")
    assert events_for(spoof) == []


def test_batch_transfer_yields_one_event_per_log_with_gas_charged_once():
    receipt = make_receipt(8_500_000_000, extra_legs=[(STRANGER, 1_000_000_000)])
    evs = events_for(receipt)
    assert len(evs) == 2
    assert all(e.is_batch for e in evs)
    assert {e.event_id for e in evs} == {"0xdeadbeef#0", "0xdeadbeef#1"}
    assert sum(e.gas_cost_wei for e in evs) == 65000 * 20_000_000_000


def test_finality_states_follow_chain_policy():
    shallow = events_for(make_receipt(8_500_000_000), confirmations=1)[0]
    assert shallow.state is SettlementState.OBSERVED
    mid = events_for(make_receipt(8_500_000_000), confirmations=5)[0]
    assert mid.state is SettlementState.PROVISIONAL
    deep = events_for(make_receipt(8_500_000_000), confirmations=200)[0]
    assert deep.state is SettlementState.FINAL
    assert ETHEREUM.finality.final_confirmations == 64


# --------------------------------------------------------------------
# ingestion
# --------------------------------------------------------------------

def test_pipe_delimited_messages_parse(directory):
    msg = exec_report("E1", "8500.00").replace("\x01", "|")
    assert parse_fix(msg)[35] == "8"


def test_non_fill_reports_create_no_obligation(directory):
    msg = "\x01".join(["35=8", "39=0", "17=E9", "60=20260811-14:30:00"])
    assert obligation_from_execution_report(msg, directory) is None


def test_missing_wallet_reference_data_is_an_error(directory):
    with pytest.raises(ValueError, match="no settlement wallet"):
        obligation_from_execution_report(
            exec_report("E1", "8500.00", account="UNKNOWN"), directory
        )


# --------------------------------------------------------------------
# reconciliation: the happy path
# --------------------------------------------------------------------

def test_clean_settlement_reconciles(directory):
    ob = obligation_from_execution_report(exec_report("E1", "8500.00"), directory)
    evs = events_for(make_receipt(8_500_000_000))
    report = reconcile([ob], evs)
    assert len(report.matches) == 1
    assert report.matches[0].method == "one-to-one"
    assert report.is_clean
    assert report.gas_cost_wei > 0


def test_partial_fills_net_into_one_transfer(directory):
    obs = [
        obligation_from_execution_report(exec_report("E1", "3000.00"), directory),
        obligation_from_execution_report(exec_report("E2", "2500.00"), directory),
        obligation_from_execution_report(exec_report("E3", "3000.00"), directory),
    ]
    report = reconcile(obs, events_for(make_receipt(8_500_000_000)))
    assert len(report.matches) == 1
    assert report.matches[0].method == "netted"
    assert len(report.matches[0].obligations) == 3
    assert report.is_clean


def test_reference_link_beats_heuristics(directory):
    ob = obligation_from_execution_report(
        exec_report("E1", "8500.00", ref="SSI-9001"), directory
    )
    ev = events_for(make_receipt(8_500_000_000))[0]
    ev.settlement_ref = "SSI-9001"
    report = reconcile([ob], [ev])
    assert report.matches[0].method == "reference"
    assert report.matches[0].confidence == 1.0


def test_commission_residual_is_explained_not_a_break(directory):
    ob = obligation_from_execution_report(
        exec_report("E1", "8500.00", commission="25.00"), directory
    )
    report = reconcile([ob], events_for(make_receipt(8_475_000_000)),
                       ReconConfig(amount_tolerance_minor=25_000_000))
    codes = {b.code for b in report.breaks}
    assert BreakCode.FEE_EXPLAINED_RESIDUAL in codes
    assert BreakCode.AMOUNT_MISMATCH not in codes
    assert report.is_clean


# --------------------------------------------------------------------
# reconciliation: the breaks
# --------------------------------------------------------------------

def test_reverted_transaction_is_not_settlement(directory):
    ob = obligation_from_execution_report(exec_report("E1", "8500.00"), directory)
    receipt = make_receipt(8_500_000_000, status="0x0")
    report = reconcile([ob], events_for(receipt))
    codes = {b.code for b in report.breaks}
    assert BreakCode.TX_REVERTED in codes
    assert BreakCode.NO_CHAIN_EVENT in codes
    assert not report.matches


def test_decimals_bug_is_caught_by_name(directory):
    """The classic: someone assumed 18 decimals for a 6-decimal token."""
    ob = obligation_from_execution_report(exec_report("E1", "8500.00"), directory)
    wrong = 8_500_000_000 * 10**12
    report = reconcile([ob], events_for(make_receipt(wrong)),
                       ReconConfig(amount_tolerance_minor=10**22))
    breaks = [b for b in report.breaks if b.code is BreakCode.DECIMAL_SCALE_SUSPECT]
    assert breaks and breaks[0].context["exponent"] == 12
    assert breaks[0].severity.value == "critical"


def test_funds_to_the_wrong_wallet_are_flagged_as_misdirection(directory):
    ob = obligation_from_execution_report(exec_report("E1", "8500.00"), directory)
    report = reconcile([ob], events_for(make_receipt(8_500_000_000, recipient=STRANGER)))
    codes = {b.code for b in report.breaks}
    assert BreakCode.WRONG_RECIPIENT in codes
    assert BreakCode.NO_FIX_OBLIGATION not in codes  # not two unrelated gaps


def test_unexplained_outflow_is_critical(directory):
    report = reconcile([], events_for(make_receipt(50_000_000_000)))
    b = next(x for x in report.breaks if x.code is BreakCode.NO_FIX_OBLIGATION)
    assert b.severity.value == "critical"


def test_missing_payment_is_a_break(directory):
    ob = obligation_from_execution_report(exec_report("E1", "8500.00"), directory)
    report = reconcile([ob], [])
    assert {b.code for b in report.breaks} == {BreakCode.NO_CHAIN_EVENT}


def test_shallow_confirmations_block_release(directory):
    ob = obligation_from_execution_report(exec_report("E1", "8500.00"), directory)
    report = reconcile([ob], events_for(make_receipt(8_500_000_000), confirmations=3))
    assert BreakCode.NOT_YET_FINAL in {b.code for b in report.breaks}
    assert report.matches  # matched, but not releasable


def test_reorg_invalidates_a_settled_event(directory):
    ob = obligation_from_execution_report(exec_report("E1", "8500.00"), directory)
    evs = events_for(make_receipt(8_500_000_000, block_hash="0xaaa"))
    assert evs[0].state is SettlementState.FINAL

    reorged = detect_reorgs(evs, {100: "0xbbb"})
    assert reorged and evs[0].state is SettlementState.REORGED

    report = reconcile([ob], evs)
    codes = {b.code for b in report.breaks}
    assert BreakCode.REORGED in codes
    assert BreakCode.NO_CHAIN_EVENT in codes
    assert not report.matches


def test_late_settlement_is_recorded(directory):
    ob = obligation_from_execution_report(
        exec_report("E1", "8500.00", settl_date="20260810"), directory
    )
    report = reconcile([ob], events_for(make_receipt(8_500_000_000)))
    assert BreakCode.LATE_SETTLEMENT in {b.code for b in report.breaks}


def test_identical_amounts_are_ambiguous_not_guessed(directory):
    obs = [
        obligation_from_execution_report(exec_report("E1", "1000.00"), directory),
        obligation_from_execution_report(exec_report("E2", "1000.00"), directory),
    ]
    r1 = make_receipt(1_000_000_000)
    r2 = {**make_receipt(1_000_000_000), "transactionHash": "0xfeed"}
    report = reconcile(obs, events_for(r1) + events_for(r2))
    assert BreakCode.AMBIGUOUS_MATCH in {b.code for b in report.breaks}


def test_subset_match_is_reported_as_partial(directory):
    obs = [
        obligation_from_execution_report(exec_report("E1", "3000.00"), directory),
        obligation_from_execution_report(exec_report("E2", "2500.00"), directory),
        obligation_from_execution_report(exec_report("E3", "9999.00"), directory),
    ]
    report = reconcile(obs, events_for(make_receipt(5_500_000_000)))
    assert BreakCode.PARTIAL_NETTING in {b.code for b in report.breaks}
    assert any(m.method == "subset" for m in report.matches)


def test_settlement_outside_the_window_does_not_match(directory):
    ob = obligation_from_execution_report(exec_report("E1", "8500.00"), directory)
    late = dt.datetime(2026, 9, 20, tzinfo=dt.timezone.utc)
    evs = decode_receipt(make_receipt(8_500_000_000), late, 1, current_block=100_000)
    report = reconcile([ob], evs)
    assert not report.matches
    assert BreakCode.NO_CHAIN_EVENT in {b.code for b in report.breaks}


# --------------------------------------------------------------------
# reporting
# --------------------------------------------------------------------

def test_agent_context_carries_the_runbook(directory):
    ob = obligation_from_execution_report(exec_report("E1", "8500.00"), directory)
    report = reconcile([ob], events_for(make_receipt(8_500_000_000, recipient=STRANGER)))
    ctx = report.to_agent_context()
    assert "WRONG_RECIPIENT" in ctx
    assert "first_action=" in ctx
    assert "severity=critical" in ctx


def test_summary_renders(directory):
    ob = obligation_from_execution_report(exec_report("E1", "8500.00"), directory)
    text = reconcile([ob], events_for(make_receipt(8_500_000_000))).summary()
    assert "matched" in text and "gas cost leg" in text
