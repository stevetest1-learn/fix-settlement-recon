"""
Tests for the forward direction, and for the round trip.

The round-trip test is the important one: a payment built by this module,
once settled, must reconcile at tier 1 against the fills it discharged.
If build and match disagree about what constitutes one settlement, the two
halves of the system are describing different realities.
"""

import datetime as dt

import pytest

from fix_settlement_recon import (
    StaticWalletDirectory,
    decode_receipt,
    obligation_from_execution_report,
    reconcile,
)
from fix_settlement_recon.instruct import (
    GAS_TRANSFER_COLD,
    InstructionError,
    SettlementWindow,
    build_payment_run,
    build_transfer_calldata,
    build_unsigned_transaction,
    net_obligations,
    preflight,
    settlement_reference,
)
from fix_settlement_recon.chains import BASE, ETHEREUM
from fix_settlement_recon.keccak import event_topic

USDC = "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
TREASURY = "0x1111111111111111111111111111111111111111"
ACME = "0x2222222222222222222222222222222222222222"
BETA = "0x3333333333333333333333333333333333333333"
ZERO = "0x0000000000000000000000000000000000000000"
TRANSFER_TOPIC = event_topic("Transfer(address,address,uint256)")

NOON = dt.datetime(2026, 8, 11, 12, 0, tzinfo=dt.timezone.utc)
CUTOFF = dt.datetime(2026, 8, 11, 21, 0, tzinfo=dt.timezone.utc)


@pytest.fixture
def directory():
    d = StaticWalletDirectory()
    d.register("ACME-FX", 1, ACME)
    d.register("BETA-CAP", 1, BETA)
    return d


def er(exec_id, account, amount, *, commission=None, time="14:30:00.000",
       settl_date="20260811"):
    tags = {35: "8", 39: "2", 17: exec_id, 37: "ORD-1", 11: "CL-1",
            1: account, 54: "1", 55: "ETH/USD", 119: str(amount), 120: "USD",
            64: settl_date, 60: f"20260811-{time}", 20002: "1"}
    if commission:
        tags[12] = str(commission)
    return "|".join(f"{k}={v}" for k, v in tags.items())


def obs(directory, *specs):
    return [obligation_from_execution_report(er(*s[:3], **(s[3] if len(s) > 3 else {})),
                                             directory) for s in specs]


# ------------------------------------------------------------------
# calldata
# ------------------------------------------------------------------

def test_calldata_puts_recipient_in_args_not_the_to_field():
    data = build_transfer_calldata(ACME, 8_500_000_000)
    assert data.startswith("0xa9059cbb")
    assert len(data) == 2 + 8 + 64 + 64
    assert data[10:74] == ACME[2:].rjust(64, "0")
    assert int(data[74:138], 16) == 8_500_000_000


def test_calldata_rejects_nonsense():
    with pytest.raises(InstructionError):
        build_transfer_calldata("0xdeadbeef", 1)          # too short
    with pytest.raises(InstructionError):
        build_transfer_calldata(ACME, 0)                  # zero value
    with pytest.raises(InstructionError):
        build_transfer_calldata(ACME, -5)                 # negative
    with pytest.raises(InstructionError):
        build_transfer_calldata("0x" + "z" * 40, 1)       # not hex


# ------------------------------------------------------------------
# netting
# ------------------------------------------------------------------

def test_partial_fills_net_into_one_payment(directory):
    o = obs(directory, ("EX-1", "ACME-FX", "3000.00"),
                       ("EX-2", "ACME-FX", "2500.00"),
                       ("EX-3", "ACME-FX", "3000.00"))
    ins = net_obligations(o)
    assert len(ins) == 1
    assert ins[0].amount.raw == 8_500_000_000
    assert ins[0].is_netted
    assert ins[0].obligation_ids == ["EX-1", "EX-2", "EX-3"]


def test_different_counterparties_do_not_net(directory):
    o = obs(directory, ("EX-1", "ACME-FX", "3000.00"),
                       ("EX-2", "BETA-CAP", "2500.00"))
    assert len(net_obligations(o)) == 2


def test_different_settle_dates_do_not_net(directory):
    o = obs(directory, ("EX-1", "ACME-FX", "3000.00"),
                       ("EX-2", "ACME-FX", "2500.00", {"settl_date": "20260812"}))
    assert len(net_obligations(o)) == 2


def test_payment_is_net_of_commission(directory):
    o = obs(directory, ("EX-1", "ACME-FX", "12000.00", {"commission": "25.00"}))
    ins = net_obligations(o)[0]
    assert ins.gross.raw == 12_000_000_000
    assert ins.amount.raw == 11_975_000_000
    assert ins.commission.raw == 25_000_000


def test_commission_exceeding_principal_is_refused(directory):
    o = obs(directory, ("EX-1", "ACME-FX", "10.00", {"commission": "25.00"}))
    with pytest.raises(InstructionError, match="commission equals or exceeds"):
        net_obligations(o)


def test_shared_wallet_across_accounts_warns(directory):
    directory.register("ACME-FX2", 1, ACME)
    o = obs(directory, ("EX-1", "ACME-FX", "1000.00"),
                       ("EX-2", "ACME-FX2", "1000.00"))
    ins = net_obligations(o)[0]
    assert any("omnibus" in w for w in ins.warnings)


# ------------------------------------------------------------------
# reference
# ------------------------------------------------------------------

def test_reference_is_deterministic_and_order_independent():
    d = dt.date(2026, 8, 11)
    a = settlement_reference(["EX-1", "EX-2", "EX-3"], d)
    b = settlement_reference(["EX-3", "EX-1", "EX-2"], d)
    assert a == b and a.startswith("SSI-")


def test_reference_changes_with_content():
    d = dt.date(2026, 8, 11)
    assert settlement_reference(["EX-1"], d) != settlement_reference(["EX-2"], d)
    assert (settlement_reference(["EX-1"], d)
            != settlement_reference(["EX-1"], dt.date(2026, 8, 12)))


# ------------------------------------------------------------------
# preflight
# ------------------------------------------------------------------

def test_paying_the_token_contract_is_blocked(directory):
    ins = net_obligations(obs(directory, ("EX-1", "ACME-FX", "100.00")))[0]
    ins.recipient = USDC
    r = preflight(ins, sender=TREASURY)
    assert not r.ok and any("token contract" in b for b in r.blockers)


def test_zero_address_is_blocked(directory):
    ins = net_obligations(obs(directory, ("EX-1", "ACME-FX", "100.00")))[0]
    ins.recipient = ZERO
    assert any("zero address" in b for b in preflight(ins, sender=TREASURY).blockers)


def test_bad_checksum_is_caught_as_a_typo(directory):
    ins = net_obligations(obs(directory, ("EX-1", "ACME-FX", "100.00")))[0]
    ins.recipient = "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB49"  # last digit changed
    assert any("checksum" in b for b in preflight(ins, sender=TREASURY).blockers)


def test_insufficient_balance_is_blocked(directory):
    ins = net_obligations(obs(directory, ("EX-1", "ACME-FX", "8500.00")))[0]
    r = preflight(ins, sender=TREASURY, sender_balance_minor=8_000_000_000)
    assert not r.ok and any("short by" in b for b in r.blockers)


def test_unapproved_wallet_is_blocked(directory):
    ins = net_obligations(obs(directory, ("EX-1", "ACME-FX", "100.00")))[0]
    r = preflight(ins, sender=TREASURY, approved_wallets={BETA})
    assert any("approved settlement wallet" in b for b in r.blockers)


def test_blocked_wallet_routes_to_compliance(directory):
    ins = net_obligations(obs(directory, ("EX-1", "ACME-FX", "100.00")))[0]
    r = preflight(ins, sender=TREASURY, blocked_wallets={ACME})
    assert any("compliance" in b for b in r.blockers)


def test_first_time_recipient_warns_not_blocks(directory):
    ins = net_obligations(obs(directory, ("EX-1", "ACME-FX", "100.00")))[0]
    r = preflight(ins, sender=TREASURY, recipient_holds_token=False)
    assert r.ok and any("never held" in w for w in r.warnings)


# ------------------------------------------------------------------
# same-day window
# ------------------------------------------------------------------

def test_same_day_is_feasible_with_hours_to_spare():
    w = SettlementWindow(cutoff=CUTOFF)
    ok, detail = w.feasible(ETHEREUM, NOON)
    assert ok and "slack" in detail


def test_submitting_too_late_blocks_same_day():
    w = SettlementWindow(cutoff=CUTOFF)
    ok, _ = w.feasible(ETHEREUM, dt.datetime(2026, 8, 11, 20, 55, tzinfo=dt.timezone.utc))
    assert not ok


def test_rollup_finality_carries_a_sequencer_warning(directory):
    o = obs(directory, ("EX-1", "ACME-FX", "100.00"))
    ins = net_obligations(o)[0]
    ins.chain_id = BASE.chain_id
    r = preflight(ins, sender=TREASURY, now=NOON, window=SettlementWindow(cutoff=CUTOFF))
    assert any("sequencer" in w for w in r.warnings)


# ------------------------------------------------------------------
# transaction
# ------------------------------------------------------------------

def test_unsigned_transaction_shape(directory):
    ins = net_obligations(obs(directory, ("EX-1", "ACME-FX", "8500.00")))[0]
    tx = build_unsigned_transaction(ins, sender=TREASURY, nonce=42,
                                    base_fee_wei=20_000_000_000)
    d = tx.to_dict()
    assert d["to"].lower() == USDC          # the contract, never the client
    assert d["value"] == "0x0"              # no ETH moves
    assert d["type"] == "0x2"
    assert int(d["nonce"], 16) == 42
    assert tx.max_fee_per_gas > 20_000_000_000
    assert ACME[2:].lower() in tx.data


def test_cold_recipient_gets_more_gas(directory):
    ins = net_obligations(obs(directory, ("EX-1", "ACME-FX", "100.00")))[0]
    warm = build_unsigned_transaction(ins, sender=TREASURY, nonce=0,
                                      base_fee_wei=10**10, recipient_holds_token=True)
    cold = build_unsigned_transaction(ins, sender=TREASURY, nonce=0,
                                      base_fee_wei=10**10, recipient_holds_token=False)
    assert cold.gas > warm.gas >= 45_000
    assert cold.gas >= GAS_TRANSFER_COLD


def test_intent_is_human_checkable(directory):
    ins = net_obligations(obs(directory, ("EX-1", "ACME-FX", "8500.00")))[0]
    tx = build_unsigned_transaction(ins, sender=TREASURY, nonce=0,
                                    base_fee_wei=10**10)
    assert "8,500" in tx.intent["pay"]
    assert tx.intent["discharges"] == "EX-1"
    assert tx.intent["reference"] == ins.reference


# ------------------------------------------------------------------
# payment run
# ------------------------------------------------------------------

def test_held_payments_do_not_consume_nonces(directory):
    o = obs(directory, ("EX-1", "ACME-FX", "3000.00"),
                       ("EX-2", "BETA-CAP", "9000.00"))
    ready, held = build_payment_run(
        o, sender=TREASURY, starting_nonce=100, base_fee_wei=10**10,
        approved_wallets={ACME}, now=NOON,
    )
    assert len(ready) == 1 and len(held) == 1
    assert ready[0][1].nonce == 100          # no gap left behind the held one
    assert held[0][0].recipient == BETA


def test_run_is_consecutively_nonced(directory):
    o = obs(directory, ("EX-1", "ACME-FX", "3000.00"),
                       ("EX-2", "BETA-CAP", "9000.00"))
    ready, held = build_payment_run(o, sender=TREASURY, starting_nonce=7,
                                    base_fee_wei=10**10, now=NOON)
    assert not held
    assert [tx.nonce for _, tx, _ in ready] == [7, 8]


def test_balance_depletes_across_the_run(directory):
    o = obs(directory, ("EX-1", "ACME-FX", "6000.00"),
                       ("EX-2", "BETA-CAP", "6000.00"))
    ready, held = build_payment_run(
        o, sender=TREASURY, starting_nonce=0, base_fee_wei=10**10,
        balances={"USDC": 10_000_000_000}, now=NOON,
    )
    assert len(ready) == 1 and len(held) == 1     # second payment unfunded
    assert any("short by" in b for b in held[0][1].blockers)


# ------------------------------------------------------------------
# the round trip
# ------------------------------------------------------------------

def test_built_payment_reconciles_at_tier_one(directory):
    """Build a payment, settle it, reconcile it. Must match on reference."""
    o = obs(directory, ("EX-1", "ACME-FX", "3000.00"),
                       ("EX-2", "ACME-FX", "2500.00"),
                       ("EX-3", "ACME-FX", "3000.00"))

    ready, held = build_payment_run(o, sender=TREASURY, starting_nonce=0,
                                    base_fee_wei=10**10, now=NOON)
    assert not held
    ins, tx, _ = ready[0]

    # The payment lands on chain, carrying the reference we recorded for it.
    pad = lambda a: "0x" + a[2:].rjust(64, "0")
    receipt = {
        "transactionHash": "0xfeed", "blockNumber": hex(21_000_000),
        "blockHash": "0xabc", "status": "0x1", "from": TREASURY, "to": USDC,
        "gasUsed": hex(tx.gas), "effectiveGasPrice": hex(tx.max_fee_per_gas),
        "logs": [{"address": USDC,
                  "topics": [TRANSFER_TOPIC, pad(TREASURY), pad(ins.recipient)],
                  "data": hex(ins.amount.raw), "logIndex": "0x0"}],
    }
    events = decode_receipt(receipt, dt.datetime(2026, 8, 11, 14, 40,
                                                 tzinfo=dt.timezone.utc),
                            chain_id=1, current_block=21_000_100)
    for e in events:
        e.settlement_ref = ins.reference
    for ob in o:
        ob.settlement_ref = ins.reference

    report = reconcile(o, events)
    assert len(report.matches) == 1
    assert report.matches[0].method == "reference"     # tier 1, not a heuristic
    assert report.matches[0].confidence == 1.0
    assert report.matches[0].residual_minor == 0
    assert report.is_clean


def test_reference_recomputes_from_fix_alone(directory):
    """A counterparty holding only the fills can derive the same reference."""
    o = obs(directory, ("EX-1", "ACME-FX", "3000.00"),
                       ("EX-2", "ACME-FX", "2500.00"))
    ins = net_obligations(o)[0]
    theirs = settlement_reference(["EX-2", "EX-1"], dt.date(2026, 8, 11))
    assert theirs == ins.reference


# ------------------------------------------------------------------
# address validation — both sides get equal scrutiny
# ------------------------------------------------------------------

def test_truncated_sender_is_blocked(directory):
    """An abbreviated address pasted from docs must never reach a signer."""
    ins = net_obligations(obs(directory, ("EX-1", "ACME-FX", "100.00")))[0]
    r = preflight(ins, sender="0x1111\u2026")
    assert not r.ok
    assert any("not 40" in b for b in r.blockers)


def test_sender_without_prefix_is_blocked(directory):
    ins = net_obligations(obs(directory, ("EX-1", "ACME-FX", "100.00")))[0]
    r = preflight(ins, sender="1111111111111111111111111111111111111111")
    assert any("must start with 0x" in b for b in r.blockers)


def test_sender_with_bad_checksum_is_blocked(directory):
    ins = net_obligations(obs(directory, ("EX-1", "ACME-FX", "100.00")))[0]
    r = preflight(ins, sender="0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB49")
    assert any("checksum" in b for b in r.blockers)


def test_truncated_recipient_is_blocked(directory):
    ins = net_obligations(obs(directory, ("EX-1", "ACME-FX", "100.00")))[0]
    ins.recipient = "0x2222\u2026"
    r = preflight(ins, sender=TREASURY)
    assert any("not 40" in b for b in r.blockers)


def test_bad_sender_holds_the_whole_run(directory):
    o = obs(directory, ("EX-1", "ACME-FX", "3000.00"),
                       ("EX-2", "BETA-CAP", "2000.00"))
    ready, held = build_payment_run(o, sender="0x1111\u2026", starting_nonce=0,
                                    base_fee_wei=10**10, now=NOON)
    assert not ready and len(held) == 2
