#!/usr/bin/env bash
# Launch the break debugger locally.
#
#   ./run.sh              serve on http://localhost:8000
#   ./run.sh 8080         serve on another port
#
# Works from either layout:
#   * a full checkout   (web/index.html + fix_settlement_recon/ source)
#   * a flat folder     (index.html + the .whl downloaded side by side)
#
# The wheel is only built when the source is present AND newer than the
# wheel. If you just downloaded the two files, nothing is built at all.

set -euo pipefail
cd "$(dirname "$0")"

PORT="${1:-8000}"
WHEEL="fix_settlement_recon-0.1.0-py3-none-any.whl"

PY="$(command -v python3 || command -v python || true)"
if [ -z "$PY" ]; then
  echo "Python 3 is not on your PATH. Install it, then run this again." >&2
  exit 1
fi

# --- where does the page live? ---------------------------------------
if   [ -f web/index.html ]; then SERVE="web"
elif [ -f index.html ];     then SERVE="."
else
  echo "Cannot find index.html." >&2
  echo >&2
  echo "Run this from the folder holding index.html, or from a checkout" >&2
  echo "where it sits in web/. Current folder:" >&2
  echo >&2
  ls -1 >&2
  exit 1
fi

have_source=false
if [ -d fix_settlement_recon ] && [ -f pyproject.toml ]; then
  have_source=true
fi

build_wheel() {
  echo "Building $WHEEL..."
  "$PY" -m pip install --quiet --upgrade build >/dev/null 2>&1 || true
  if ! "$PY" -m build --wheel --outdir dist >/dev/null 2>&1; then
    echo "Wheel build failed. Run '$PY -m build --wheel' to see why." >&2
    exit 1
  fi
  cp "dist/$WHEEL" "$SERVE/$WHEEL"
}

# --- make sure the wheel is there ------------------------------------
if [ ! -f "$SERVE/$WHEEL" ]; then
  # A browser may have saved it as "...any (1).whl" or similar. Adopt any
  # matching wheel rather than making you rename it by hand.
  shopt -s nullglob
  strays=( "$SERVE"/fix_settlement_recon*.whl ./fix_settlement_recon*.whl )
  shopt -u nullglob

  if [ ${#strays[@]} -gt 0 ]; then
    echo "Using ${strays[0]}"
    cp "${strays[0]}" "$SERVE/$WHEEL"
  elif $have_source; then
    build_wheel
  else
    echo "Cannot find $WHEEL." >&2
    echo >&2
    echo "The page needs two files in the same folder:" >&2
    echo "  index.html" >&2
    echo "  $WHEEL" >&2
    echo >&2
    echo "Download the wheel and put it next to index.html, or run this from" >&2
    echo "a full checkout so it can be built. Current folder:" >&2
    echo >&2
    ls -1 >&2
    exit 1
  fi
fi

# --- rebuild only if you have source and have edited it --------------
if $have_source; then
  shopt -s nullglob
  for src in fix_settlement_recon/*.py; do
    if [ "$src" -nt "$SERVE/$WHEEL" ]; then
      build_wheel
      break
    fi
  done
  shopt -u nullglob
fi

URL="http://localhost:$PORT"
echo
echo "  Break debugger  ->  $URL"
echo "  Serving $SERVE/ . Nothing leaves this machine. Ctrl-C to stop."
echo

( sleep 1
  if   command -v open     >/dev/null 2>&1; then open "$URL"
  elif command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL"
  fi ) >/dev/null 2>&1 &

exec "$PY" -m http.server "$PORT" --directory "$SERVE"
