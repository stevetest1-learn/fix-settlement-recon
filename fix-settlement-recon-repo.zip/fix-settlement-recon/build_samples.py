#!/usr/bin/env python3
"""
Generate the sample scenarios the website loads.

Each scenario is a self-contained payload for webbridge.run(): fills,
wallets, receipts. Visitors pick one and see a real break without needing
their own trade data — which is what makes the page a demonstration rather
than an empty form.

    python3 build_samples.py

You only need this to add or change a scenario. The samples/ folder ships
already generated.

Runs from anywhere: it finds the package whether it sits beside this file,
one level up, or is pip-installed.
"""

import datetime as dt
import json
import pathlib
import sys

_HERE = pathlib.Path(__file__).resolve().parent

# Look for the package beside this file and one level up, so the script works
# from the project root or from inside web/.
for _candidate in (_HERE, _HERE.parent):
    if (_candidate / "fix_settlement_recon" / "__init__.py").exists():
        sys.path.insert(0, str(_candidate))
        break

try:
    from fix_settlement_recon.keccak import event_topic
except ModuleNotFoundError:
    sys.exit(
        "Cannot import fix_settlement_recon.\n\n"
        "Either run this from the project root (the folder containing the\n"
        "fix_settlement_recon/ directory), or install the package first:\n\n"
        "    python3 -m venv ~/.venvs/recon\n"
        "    ~/.venvs/recon/bin/pip install fix_settlement_recon-0.1.0-py3-none-any.whl\n"
        "    ~/.venvs/recon/bin/python build_samples.py\n\n"
        "You do not need to run this at all unless you are changing a scenario —\n"
        "web/samples/ ships already generated."
    )


def _output_dir() -> pathlib.Path:
    """Write to web/samples when there is a web/, otherwise ./samples."""
    if (_HERE / "web").is_dir():
        return _HERE / "web" / "samples"
    if _HERE.name == "web":
        return _HERE / "samples"
    return _HERE / "samples"


OUT = _output_dir()

USDC = "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
VENUE = "0x1111111111111111111111111111111111111111"
ACME = "0x2222222222222222222222222222222222222222"
BETA = "0x3333333333333333333333333333333333333333"
OTHER = "0x4444444444444444444444444444444444444444"
TOPIC = event_topic("Transfer(address,address,uint256)")

HEAD = 21_000_500


def pad(a):
    return "0x" + a[2:].rjust(64, "0")


def ts(hh=14, mm=40):
    return hex(int(dt.datetime(2026, 8, 11, hh, mm,
                               tzinfo=dt.timezone.utc).timestamp()))


def rcpt(tx, block, legs, status="0x1", hh=14, mm=40):
    to, amt = legs[0]
    calldata = ("0xa9059cbb" + to[2:].rjust(64, "0") + f"{amt:064x}"
                if len(legs) == 1 else "0x")
    return {
        "transactionHash": tx, "input": calldata,
        "blockNumber": hex(block), "blockHash": "0x" + format(block, "064x"),
        "status": status, "from": VENUE, "to": USDC, "timestamp": ts(hh, mm),
        "gasUsed": hex(52_000 + 26_000 * (len(legs) - 1)),
        "effectiveGasPrice": "0x431bde00",
        "logs": [{"address": USDC, "topics": [TOPIC, pad(VENUE), pad(to)],
                  "data": hex(amt), "logIndex": hex(i)}
                 for i, (to, amt) in enumerate(legs)],
    }


def er(eid, acct, amt, **over):
    t = {35: "8", 39: "2", 17: eid, 37: f"ORD-{eid}", 11: f"CL-{eid}",
         1: acct, 54: "1", 55: "ETH/USD", 32: "2.5", 31: "3400.00",
         119: amt, 120: "USD", 64: "20260811",
         60: "20260811-14:30:00.000", 20002: "1"}
    t.update({int(k): v for k, v in over.items()})
    return "|".join(f"{k}={v}" for k, v in t.items())


SCENARIOS = [
    {
        "id": "clean-netted",
        "title": "Clean netted settlement",
        "teaser": "Three partial fills discharged by one payment.",
        "expect": "No breaks. The netting group sums exactly to the transfer.",
        "payload": {
            "fix": "\n".join([
                er("EX-1001", "ACME-FX", "3000.00"),
                er("EX-1002", "ACME-FX", "2500.00", **{"60": "20260811-14:31:12.500"}),
                er("EX-1003", "ACME-FX", "3000.00", **{"60": "20260811-14:33:47.100"}),
            ]),
            "wallets": {"ACME-FX": ACME},
            "receipts": [rcpt("0xaa01", 21_000_000, [(ACME, 8_500_000_000)])],
            "current_block": HEAD, "chain_id": 1, "config": {},
        },
    },
    {
        "id": "reverted-payment",
        "title": "Mined but reverted",
        "teaser": "The transaction is in a block. Nothing moved.",
        "expect": "TX_REVERTED plus NO_CHAIN_EVENT — inclusion is not settlement.",
        "payload": {
            "fix": er("EX-2001", "BETA-CAP", "4750.00"),
            "wallets": {"BETA-CAP": BETA},
            "receipts": [rcpt("0xcc03", 21_000_200, [(BETA, 4_750_000_000)],
                              status="0x0")],
            "current_block": HEAD, "chain_id": 1, "config": {},
        },
    },
    {
        "id": "decimals-bug",
        "title": "The decimals bug",
        "teaser": "Someone assumed 18 decimals for a 6-decimal token.",
        "expect": "DECIMAL_SCALE_SUSPECT, naming the exact power of ten.",
        "payload": {
            "fix": er("EX-3001", "ACME-FX", "8500.00"),
            "wallets": {"ACME-FX": ACME},
            "receipts": [rcpt("0xdd04", 21_000_300,
                              [(ACME, 8_500_000_000 * 10**12)])],
            "current_block": HEAD, "chain_id": 1,
            "config": {"amount_tolerance_minor": 10**22},
        },
    },
    {
        "id": "wrong-recipient",
        "title": "Funds to the wrong wallet",
        "teaser": "Right amount, right window, wrong destination.",
        "expect": "WRONG_RECIPIENT — not two unrelated gaps.",
        "payload": {
            "fix": er("EX-4001", "ACME-FX", "8500.00"),
            "wallets": {"ACME-FX": ACME},
            "receipts": [rcpt("0xee05", 21_000_400, [(OTHER, 8_500_000_000)])],
            "current_block": HEAD, "chain_id": 1, "config": {},
        },
    },
    {
        "id": "batch-with-stray",
        "title": "Batch with an unexplained leg",
        "teaser": "One transaction, two clients, one with no fill behind it.",
        "expect": "A clean match plus NO_FIX_OBLIGATION on the stray leg.",
        "payload": {
            "fix": er("EX-5001", "BETA-CAP", "12000.00", **{"12": "25.00"}),
            "wallets": {"BETA-CAP": BETA},
            "receipts": [rcpt("0xbb02", 21_000_100,
                              [(BETA, 11_975_000_000), (OTHER, 900_000_000)])],
            "current_block": HEAD, "chain_id": 1,
            "config": {"amount_tolerance_minor": 25_000_000},
        },
    },
    {
        "id": "not-yet-final",
        "title": "Matched but not releasable",
        "teaser": "Correct payment, three confirmations deep.",
        "expect": "NOT_YET_FINAL. Matched is not the same as safe to release.",
        "payload": {
            "fix": er("EX-6001", "ACME-FX", "8500.00"),
            "wallets": {"ACME-FX": ACME},
            "receipts": [rcpt("0xff06", 21_000_498, [(ACME, 8_500_000_000)])],
            "current_block": 21_000_500, "chain_id": 1, "config": {},
        },
    },
]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    manifest = []
    for s in SCENARIOS:
        (OUT / f"{s['id']}.json").write_text(
            json.dumps(s["payload"], indent=1), encoding="utf-8"
        )
        manifest.append({k: s[k] for k in ("id", "title", "teaser", "expect")})
    (OUT / "manifest.json").write_text(
        json.dumps(manifest, indent=1), encoding="utf-8"
    )
    print(f"Wrote {len(SCENARIOS)} scenarios + manifest to:\n  {OUT}")
    print("\nServe the folder containing index.html to see them.")


if __name__ == "__main__":
    main()
