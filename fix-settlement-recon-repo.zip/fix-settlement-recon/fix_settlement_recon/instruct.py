"""
Settlement instruction builder — the forward direction.

The reconciler answers "did these two things match?" after the fact. This
answers "what payment discharges these fills, and can it settle today?"
before the money moves.

Three things make this more than string formatting:

1. **Netting.** Same-day settlement means one payment per counterparty per
   currency, not one per fill. Five partial fills become one transfer. The
   netting is the whole point — it is what makes same-day economically
   possible when gas is a per-transaction cost.

2. **The settlement reference.** The reconciler's most reliable match is a
   deterministic reference present on both sides, and venues usually don't
   provide one. When you build the payment, you can. The reference is
   derived from the ExecIDs it discharges, so it is reproducible from the
   FIX side alone and needs no shared state to verify.

3. **A cutoff that accounts for finality.** "Settles today" does not mean
   "submitted today." It means final before the cutoff, so the deadline is
   cutoff minus time-to-finality minus a submission buffer. On an optimistic
   rollup that calculation involves a credit decision, not just arithmetic.

WHAT THIS DELIBERATELY DOES NOT DO
----------------------------------
It does not sign. It does not broadcast. It does not touch a private key,
and there is no code path in this module that could.

That is how treasury systems are built: the constructor emits an unsigned
payload, a separate signer (HSM, MPC, hardware wallet) applies the key under
maker-checker approval, and a third component broadcasts. Collapsing those
into one process gives you a service that can move funds unilaterally, which
is not deployable at any venue that has a risk function.

The output here is an unsigned EIP-1559 transaction dict. Hand it to your
signing infrastructure.
"""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Iterable, Sequence

from .chains import Chain, get_chain, token_for_currency
from .keccak import function_selector, keccak256, to_checksum_address
from .models import SettlementObligation, TokenAmount

TRANSFER_SELECTOR = function_selector("transfer(address,uint256)")

#: Gas for an ERC-20 transfer. The recipient's current balance decides which:
#: moving a zero slot to non-zero costs an extra 20k (SSTORE from empty).
GAS_TRANSFER_WARM = 45_000    # recipient already holds this token
GAS_TRANSFER_COLD = 65_000    # recipient's balance is currently zero
GAS_SAFETY_MARGIN = Decimal("1.25")


class InstructionError(ValueError):
    """The instruction cannot be built as specified."""


@dataclass(frozen=True)
class SettlementWindow:
    """When 'today' ends, and how much room the chain needs before it.

    ``cutoff`` is your operational deadline — the point by which funds must
    be final, usually driven by a counterparty's own cutoff or your treasury
    reporting. ``submission_buffer`` is slack for mempool congestion and for
    a resubmit if the first attempt underprices gas.
    """
    cutoff: dt.datetime
    submission_buffer: dt.timedelta = dt.timedelta(minutes=20)

    def latest_submission(self, chain: Chain) -> dt.datetime:
        return (
            self.cutoff
            - dt.timedelta(seconds=chain.finality.expected_seconds_to_final)
            - self.submission_buffer
        )

    def feasible(self, chain: Chain, now: dt.datetime) -> tuple[bool, str]:
        latest = self.latest_submission(chain)
        if now <= latest:
            spare = latest - now
            return True, f"{int(spare.total_seconds() // 60)} min of slack before cutoff"
        late = now - latest
        return False, (
            f"{int(late.total_seconds() // 60)} min past the latest submission time "
            f"for same-day finality on {chain.name}"
        )


@dataclass
class SettlementInstruction:
    """One payment discharging one or more obligations."""
    reference: str
    chain_id: int
    token_symbol: str
    token_address: str
    sender: str
    recipient: str
    amount: TokenAmount
    obligation_ids: list[str]
    settle_date: dt.date
    fix_currency: str
    account: str
    gross: TokenAmount | None = None
    commission: TokenAmount | None = None
    warnings: list[str] = field(default_factory=list)

    @property
    def is_netted(self) -> bool:
        return len(self.obligation_ids) > 1

    def __str__(self) -> str:
        return (
            f"{self.reference}  {self.amount}  -> {self.recipient[:10]}…  "
            f"({len(self.obligation_ids)} fill(s), settles {self.settle_date})"
        )


@dataclass
class UnsignedTransaction:
    """An EIP-1559 transaction, ready for a signer. No key material here."""
    chain_id: int
    to: str                 # the TOKEN CONTRACT, not the recipient
    value: int              # always 0 for an ERC-20 transfer
    data: str               # calldata carrying the real recipient
    gas: int
    max_fee_per_gas: int
    max_priority_fee_per_gas: int
    nonce: int
    reference: str
    #: what this payment is meant to do, for a human approver to check
    intent: dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "chainId": self.chain_id,
            "to": self.to,
            "value": hex(self.value),
            "data": self.data,
            "gas": hex(self.gas),
            "maxFeePerGas": hex(self.max_fee_per_gas),
            "maxPriorityFeePerGas": hex(self.max_priority_fee_per_gas),
            "nonce": hex(self.nonce),
            "type": "0x2",
        }

    @property
    def max_gas_cost_wei(self) -> int:
        return self.gas * self.max_fee_per_gas


def settlement_reference(obligation_ids: Sequence[str], settle_date: dt.date) -> str:
    """A deterministic reference for the payment discharging these fills.

    Derived from the sorted ExecIDs plus the settlement date, so it is
    reproducible from the FIX side alone — anyone holding the execution
    reports can recompute it and confirm which payment should carry it,
    without access to your payment system.

    Emitted on the payment (in your records, or in a memo field if the
    counterparty supports one) it turns the reconciler's hardest problem
    into a dictionary lookup.
    """
    if not obligation_ids:
        raise InstructionError("cannot reference a payment that discharges nothing")
    seed = "|".join(sorted(obligation_ids)) + "|" + settle_date.isoformat()
    return "SSI-" + keccak256(seed.encode()).hex()[:16].upper()


def build_transfer_calldata(recipient: str, amount_minor: int) -> str:
    """ABI-encode ``transfer(address,uint256)``.

    The recipient goes in the calldata, left-padded to 32 bytes. The
    transaction's ``to`` field is the token contract. Getting these the wrong
    way round sends nothing and reverts, or — far worse on a token that
    accepts it — sends funds to the contract itself, where they are gone.
    """
    addr = recipient.removeprefix("0x").lower()
    if len(addr) != 40:
        raise InstructionError(f"not a 20-byte address: {recipient!r}")
    try:
        int(addr, 16)
    except ValueError:
        raise InstructionError(f"address is not hex: {recipient!r}") from None
    if amount_minor <= 0:
        raise InstructionError(f"refusing to build a transfer of {amount_minor}")
    if amount_minor >= 2**256:
        raise InstructionError("amount exceeds uint256")
    return TRANSFER_SELECTOR + addr.rjust(64, "0") + format(amount_minor, "064x")


def net_obligations(
    obligations: Iterable[SettlementObligation],
    *,
    net_of_commission: bool = True,
) -> list[SettlementInstruction]:
    """Collapse obligations into one instruction per counterparty settlement.

    Grouping is by (chain, wallet, currency, settle date) — the same key the
    reconciler uses to match, which is not a coincidence. Build and match
    must agree on what constitutes one settlement or the two halves disagree
    about reality.
    """
    groups: dict[tuple, list[SettlementObligation]] = {}
    for ob in obligations:
        groups.setdefault(ob.netting_key, []).append(ob)

    instructions: list[SettlementInstruction] = []
    for key, group in groups.items():
        chain_id, wallet, currency, settle_date = key
        token = token_for_currency(chain_id, currency)
        if token is None:
            raise InstructionError(
                f"no settlement token registered for {currency} on chain {chain_id}"
            )

        decimals = group[0].amount.decimals
        if any(o.amount.decimals != decimals for o in group):
            raise InstructionError(
                f"mixed token scales within one netting group for {wallet[:10]}…"
            )

        gross_raw = sum(o.amount.raw for o in group)
        commission_raw = sum(o.commission.raw for o in group if o.commission)
        net_raw = gross_raw - commission_raw if net_of_commission else gross_raw

        warnings: list[str] = []
        if net_raw <= 0:
            raise InstructionError(
                f"net settlement for {wallet[:10]}… is {net_raw} minor units; "
                "commission equals or exceeds the principal"
            )

        sides = {o.side for o in group}
        if len(sides) > 1:
            warnings.append(
                "netting group mixes buys and sells; confirm the sign convention "
                "before releasing"
            )

        accounts = {o.account for o in group}
        if len(accounts) > 1:
            warnings.append(
                f"one wallet serves {len(accounts)} accounts "
                f"({', '.join(sorted(accounts))}); confirm this is an omnibus "
                "arrangement and not stale reference data"
            )

        ids = [o.obligation_id for o in group]
        instructions.append(SettlementInstruction(
            reference=settlement_reference(ids, settle_date),
            chain_id=chain_id,
            token_symbol=token.symbol,
            token_address=token.address,
            sender="",                       # filled by the caller's treasury wallet
            recipient=wallet,
            amount=TokenAmount(net_raw, decimals, token.symbol),
            obligation_ids=sorted(ids),
            settle_date=settle_date,
            fix_currency=currency,
            account=sorted(accounts)[0],
            gross=TokenAmount(gross_raw, decimals, token.symbol),
            commission=(TokenAmount(commission_raw, decimals, token.symbol)
                        if commission_raw else None),
            warnings=warnings,
        ))

    instructions.sort(key=lambda i: (-i.amount.raw, i.reference))
    return instructions


@dataclass
class PreflightResult:
    """Whether an instruction is safe to sign, and why not if it isn't."""
    blockers: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.blockers


def _address_fault(address: str, role: str) -> str | None:
    """Return why ``address`` is unusable, or None if it looks well-formed."""
    if not address:
        return f"No {role} address specified."
    if not address.startswith("0x"):
        return f"{role.capitalize()} address must start with 0x: {address!r}"
    raw = address[2:]
    if len(raw) != 40:
        return (
            f"{role.capitalize()} address is {len(raw)} hex characters, not 40: "
            f"{address!r}. A truncated or abbreviated address cannot be used — "
            f"paste the full value."
        )
    try:
        int(raw, 16)
    except ValueError:
        return f"{role.capitalize()} address contains non-hex characters: {address!r}"
    if raw != raw.lower() and raw != raw.upper():
        if to_checksum_address(address) != "0x" + raw:
            return (
                f"{role.capitalize()} address fails its EIP-55 checksum — "
                f"it has a typo."
            )
    return None


def preflight(
    instruction: SettlementInstruction,
    *,
    sender: str,
    sender_balance_minor: int | None = None,
    recipient_holds_token: bool | None = None,
    approved_wallets: set[str] | None = None,
    blocked_wallets: set[str] | None = None,
    now: dt.datetime | None = None,
    window: SettlementWindow | None = None,
) -> PreflightResult:
    """Check an instruction before anyone is asked to sign it.

    Everything here is a check that is cheap now and expensive later. A
    reverted transfer still costs gas and still misses the cutoff; a transfer
    to a stale address costs the principal.

    Both addresses get the same scrutiny. An unvalidated sender is not a
    smaller problem than an unvalidated recipient — it just fails later, at
    signing time, after a human has already approved the payment.
    """
    res = PreflightResult(warnings=list(instruction.warnings))
    now = now or dt.datetime.now(dt.timezone.utc)

    sender_fault = _address_fault(sender, "sending wallet")
    if sender_fault:
        res.blockers.append(sender_fault)

    recipient_fault = _address_fault(instruction.recipient, "recipient")
    if recipient_fault:
        res.blockers.append(recipient_fault)

    if sender and instruction.recipient and not sender_fault and not recipient_fault:
        if sender.lower() == instruction.recipient.lower():
            res.blockers.append("Sender and recipient are the same address.")

    if instruction.recipient.lower() == instruction.token_address.lower():
        res.blockers.append(
            "Recipient is the token contract itself. Funds sent there are "
            "unrecoverable."
        )
    if not recipient_fault and set(instruction.recipient[2:]) == {"0"}:
        res.blockers.append("Recipient is the zero address.")

    if blocked_wallets and instruction.recipient.lower() in {
        w.lower() for w in blocked_wallets
    }:
        res.blockers.append(
            "Recipient is on the blocked list. A transfer to a frozen address "
            "reverts and burns gas; escalate to compliance."
        )
    if approved_wallets is not None and instruction.recipient.lower() not in {
        w.lower() for w in approved_wallets
    }:
        res.blockers.append(
            "Recipient is not on the approved settlement wallet list. Route "
            "through the SSI maker-checker process before paying."
        )

    if sender_balance_minor is not None:
        if sender_balance_minor < instruction.amount.raw:
            short = TokenAmount(
                instruction.amount.raw - sender_balance_minor,
                instruction.amount.decimals, instruction.amount.symbol,
            )
            res.blockers.append(f"Sending wallet is short by {short}.")
        elif sender_balance_minor < instruction.amount.raw * 2:
            res.warnings.append(
                "This payment consumes more than half the wallet's balance; "
                "check the rest of today's queue still funds."
            )

    if recipient_holds_token is False:
        res.warnings.append(
            "Recipient has never held this token. Costs ~20k more gas, and is "
            "worth a second look — a first-time destination is where "
            "misdirected funds go."
        )

    if window is not None:
        chain = get_chain(instruction.chain_id)
        feasible, detail = window.feasible(chain, now)
        (res.warnings if feasible else res.blockers).append(
            ("Same-day settlement viable: " if feasible
             else "Cannot reach same-day finality: ") + detail
        )
        if feasible and chain.finality.sequencer_trust_required:
            res.warnings.append(
                "Same-day finality here assumes the sequencer. Hard finality "
                "needs the challenge window — confirm the counterparty accepts "
                "delivery on that basis."
            )

    return res


def build_unsigned_transaction(
    instruction: SettlementInstruction,
    *,
    sender: str,
    nonce: int,
    base_fee_wei: int,
    priority_fee_wei: int | None = None,
    recipient_holds_token: bool | None = None,
    gas_limit: int | None = None,
) -> UnsignedTransaction:
    """Produce the unsigned EIP-1559 payload for a signer.

    ``maxFeePerGas`` is set to twice the base fee plus the tip, which is the
    usual guidance: base fee can rise at most 12.5% per block, so 2x absorbs
    roughly six consecutive full blocks. Underpricing here is how a same-day
    payment quietly misses its cutoff.
    """
    if not sender:
        raise InstructionError("a sending wallet is required")
    if nonce < 0:
        raise InstructionError(f"invalid nonce {nonce}")

    data = build_transfer_calldata(instruction.recipient, instruction.amount.raw)

    if gas_limit is None:
        base = GAS_TRANSFER_COLD if recipient_holds_token is False else GAS_TRANSFER_WARM
        gas_limit = int(Decimal(base) * GAS_SAFETY_MARGIN)

    tip = priority_fee_wei if priority_fee_wei is not None else 1_500_000_000
    max_fee = base_fee_wei * 2 + tip

    return UnsignedTransaction(
        chain_id=instruction.chain_id,
        to=to_checksum_address(instruction.token_address),
        value=0,
        data=data,
        gas=gas_limit,
        max_fee_per_gas=max_fee,
        max_priority_fee_per_gas=tip,
        nonce=nonce,
        reference=instruction.reference,
        intent={
            "pay": str(instruction.amount),
            "to": to_checksum_address(instruction.recipient),
            "account": instruction.account,
            "discharges": ", ".join(instruction.obligation_ids),
            "settle_date": instruction.settle_date.isoformat(),
            "reference": instruction.reference,
        },
    )


def build_payment_run(
    obligations: Sequence[SettlementObligation],
    *,
    sender: str,
    starting_nonce: int,
    base_fee_wei: int,
    priority_fee_wei: int | None = None,
    window: SettlementWindow | None = None,
    approved_wallets: set[str] | None = None,
    blocked_wallets: set[str] | None = None,
    balances: dict[str, int] | None = None,
    now: dt.datetime | None = None,
) -> tuple[list[tuple[SettlementInstruction, UnsignedTransaction, PreflightResult]],
           list[tuple[SettlementInstruction, PreflightResult]]]:
    """Build a full day's payment run. Returns (ready, held).

    Nonces are assigned only to instructions that pass preflight, and they
    are assigned consecutively. This matters more than it looks: nonces
    execute in order, so a gap left by a held payment stalls every payment
    behind it until the gap is filled. Skipping the number entirely is
    correct; reserving it is not.
    """
    instructions = net_obligations(obligations)
    ready: list[tuple[SettlementInstruction, UnsignedTransaction, PreflightResult]] = []
    held: list[tuple[SettlementInstruction, PreflightResult]] = []

    nonce = starting_nonce
    for ins in instructions:
        ins.sender = sender
        balance = (balances or {}).get(ins.token_symbol.upper())
        check = preflight(
            ins,
            sender=sender,
            sender_balance_minor=balance,
            approved_wallets=approved_wallets,
            blocked_wallets=blocked_wallets,
            now=now,
            window=window,
        )
        if not check.ok:
            held.append((ins, check))
            continue
        tx = build_unsigned_transaction(
            ins, sender=sender, nonce=nonce,
            base_fee_wei=base_fee_wei, priority_fee_wei=priority_fee_wei,
        )
        ready.append((ins, tx, check))
        nonce += 1
        if balance is not None:
            balances[ins.token_symbol.upper()] = balance - ins.amount.raw

    return ready, held
