"""
Keccak-256 (Ethereum variant), pure Python, no dependencies.

This exists so the module can *derive* event topic hashes and function
selectors from their canonical signatures rather than hardcoding magic
constants copied off a block explorer. If the constant is wrong, the
tests fail loudly instead of silently missing every log.

Note: this is original Keccak (0x01 domain padding), NOT NIST SHA3
(0x06 padding). hashlib.sha3_256 will give you a different digest and
is the single most common way people get this wrong.
"""

from __future__ import annotations

_MASK64 = (1 << 64) - 1
_RATE = 136  # bytes; 1088-bit rate for Keccak-256

_RC = [
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A, 0x8000000080008000,
    0x000000000000808B, 0x0000000080000001, 0x8000000080008081, 0x8000000000008009,
    0x000000000000008A, 0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089, 0x8000000000008003,
    0x8000000000008002, 0x8000000000000080, 0x000000000000800A, 0x800000008000000A,
    0x8000000080008081, 0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
]

# Rotation offsets, indexed [x][y]
_R = [
    [0, 36, 3, 41, 18],
    [1, 44, 10, 45, 2],
    [62, 6, 43, 15, 61],
    [28, 55, 25, 21, 56],
    [27, 20, 39, 8, 14],
]


def _rotl(x: int, n: int) -> int:
    return ((x << n) | (x >> (64 - n))) & _MASK64


def _keccak_f(A: list[list[int]]) -> list[list[int]]:
    for rnd in range(24):
        # theta
        C = [A[x][0] ^ A[x][1] ^ A[x][2] ^ A[x][3] ^ A[x][4] for x in range(5)]
        D = [C[(x - 1) % 5] ^ _rotl(C[(x + 1) % 5], 1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                A[x][y] ^= D[x]

        # rho + pi
        B = [[0] * 5 for _ in range(5)]
        for x in range(5):
            for y in range(5):
                B[y][(2 * x + 3 * y) % 5] = _rotl(A[x][y], _R[x][y])

        # chi
        for x in range(5):
            for y in range(5):
                A[x][y] = B[x][y] ^ ((~B[(x + 1) % 5][y] & _MASK64) & B[(x + 2) % 5][y])

        # iota
        A[0][0] ^= _RC[rnd]
    return A


def keccak256(data: bytes) -> bytes:
    """Return the 32-byte Keccak-256 digest of ``data``."""
    padded = bytearray(data)
    padded.append(0x01)
    while len(padded) % _RATE != 0:
        padded.append(0x00)
    padded[-1] ^= 0x80

    A = [[0] * 5 for _ in range(5)]
    for off in range(0, len(padded), _RATE):
        block = padded[off:off + _RATE]
        for i in range(_RATE // 8):
            lane = int.from_bytes(block[i * 8:(i + 1) * 8], "little")
            A[i % 5][i // 5] ^= lane
        A = _keccak_f(A)

    out = b"".join(A[i % 5][i // 5].to_bytes(8, "little") for i in range(4))
    return out[:32]


def event_topic(signature: str) -> str:
    """keccak256 of a canonical event signature, as an 0x-prefixed hex string.

    >>> event_topic("Transfer(address,address,uint256)")[:10]
    '0xddf252ad'
    """
    return "0x" + keccak256(signature.encode()).hex()


def function_selector(signature: str) -> str:
    """First 4 bytes of keccak256(signature) — the calldata selector.

    >>> function_selector("transfer(address,uint256)")
    '0xa9059cbb'
    """
    return "0x" + keccak256(signature.encode())[:4].hex()


def to_checksum_address(address: str) -> str:
    """EIP-55 mixed-case checksum encoding of a 20-byte hex address."""
    raw = address.lower().removeprefix("0x")
    if len(raw) != 40:
        raise ValueError(f"not a 20-byte address: {address!r}")
    digest = keccak256(raw.encode()).hex()
    return "0x" + "".join(
        ch.upper() if ch.isalpha() and int(digest[i], 16) >= 8 else ch
        for i, ch in enumerate(raw)
    )


def is_checksum_address(address: str) -> bool:
    """True if ``address`` carries a valid EIP-55 checksum (or is all one case)."""
    raw = address.removeprefix("0x")
    if len(raw) != 40:
        return False
    if raw == raw.lower() or raw == raw.upper():
        return True  # no checksum claimed
    return to_checksum_address(address) == "0x" + raw
