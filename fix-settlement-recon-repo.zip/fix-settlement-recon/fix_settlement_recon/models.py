"""
Domain model.

The central modelling decision: a FIX fill produces a *settlement
obligation*, and a chain transfer produces a *settlement event*. These
are separate types with a many-to-one relationship, because that is what
actually happens — five partial fills net into one USDC transfer, and
one batch transfer can discharge fifty clients' obligations at once.

Modelling this as "match fill to transaction" instead collapses under
the first netted settlement you see in production.
"""

from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from enum import Enum


class PrecisionError(ValueError):
    """Raised when a FIX amount cannot be represented in the token's minor units."""


@dataclass(frozen=True, order=True)
class TokenAmount:
    """An exact token amount, held as integer minor units.

    Never construct these from floats. 8500.00 USDC is 8_500_000_000
    minor units; a float round-trip through 0.1 + 0.2 is how you end up
    with a one-wei break that nobody can explain at 4am.
    """
    raw: int
    decimals: int
    symbol: str = field(compare=False, default="")

    @classmethod
    def from_decimal_str(cls, value: str, decimals: int, symbol: str = "") -> "TokenAmount":
        try:
            d = Decimal(str(value))
        except InvalidOperation:
            raise PrecisionError(f"not a decimal amount: {value!r}") from None
        scaled = d.scaleb(decimals)
        if scaled != scaled.to_integral_value():
            raise PrecisionError(
                f"{value} has more precision than {symbol or 'token'} supports "
                f"({decimals} decimals) — cannot be settled exactly"
            )
        return cls(int(scaled), decimals, symbol)

    @property
    def decimal(self) -> Decimal:
        return Decimal(self.raw).scaleb(-self.decimals)

    def __str__(self) -> str:
        return f"{self.decimal:,f} {self.symbol}".strip()

    def __add__(self, other: "TokenAmount") -> "TokenAmount":
        self._assert_compatible(other)
        return TokenAmount(self.raw + other.raw, self.decimals, self.symbol)

    def __sub__(self, other: "TokenAmount") -> "TokenAmount":
        self._assert_compatible(other)
        return TokenAmount(self.raw - other.raw, self.decimals, self.symbol)

    def _assert_compatible(self, other: "TokenAmount") -> None:
        if self.decimals != other.decimals:
            raise ValueError(
                f"refusing to combine amounts with different scales "
                f"({self.decimals} vs {other.decimals} decimals)"
            )


class SettlementState(str, Enum):
    """Where a chain event sits on the road to being safe to release against."""
    OBSERVED = "observed"            # seen in mempool or a block, no depth
    PROVISIONAL = "provisional"      # enough depth to acknowledge, not to release
    FINAL = "final"                  # safe to release against
    REVERTED = "reverted"            # mined, consumed gas, moved nothing
    REORGED = "reorged"              # was included, block no longer canonical


class Side(str, Enum):
    BUY = "1"
    SELL = "2"


@dataclass
class SettlementObligation:
    """One FIX fill's worth of cash that must move on chain."""
    obligation_id: str               # tag 17 ExecID
    account: str                     # tag 1
    order_id: str                    # tag 37
    cl_ord_id: str                   # tag 11
    side: Side                       # tag 54
    instrument: str                  # tag 55
    amount: TokenAmount              # tag 119 SettlCurrAmt, in token minor units
    fix_currency: str                # tag 120 SettlCurrency
    settle_date: dt.date             # tag 64
    transact_time: dt.datetime       # tag 60
    counterparty_wallet: str         # resolved from ref data or Parties group
    chain_id: int
    commission: TokenAmount | None = None   # tag 12
    last_qty: Decimal | None = None         # tag 32
    last_px: Decimal | None = None          # tag 31
    settlement_ref: str | None = None       # deterministic link, when the venue provides one
    raw: dict[int, str] = field(default_factory=dict, repr=False)

    @property
    def netting_key(self) -> tuple:
        """Obligations sharing this key are eligible to net into one transfer."""
        return (
            self.chain_id,
            self.counterparty_wallet.lower(),
            self.fix_currency.upper(),
            self.settle_date,
        )


@dataclass
class ChainSettlementEvent:
    """One ERC-20 Transfer log, plus the receipt context needed to judge it."""
    tx_hash: str
    log_index: int
    block_number: int
    block_hash: str
    block_timestamp: dt.datetime
    chain_id: int
    token_address: str
    token_symbol: str
    sender: str
    recipient: str
    amount: TokenAmount
    receipt_status: int = 1                  # 0 == reverted
    gas_cost_wei: int = 0                    # cost leg; has no FIX counterpart
    confirmations: int = 0
    state: SettlementState = SettlementState.OBSERVED
    settlement_ref: str | None = None
    logs_in_tx: int = 1                      # >1 means this was a batch settlement

    @property
    def event_id(self) -> str:
        """Unique within a chain. The tx hash alone is NOT unique for batches."""
        return f"{self.tx_hash}#{self.log_index}"

    @property
    def is_batch(self) -> bool:
        return self.logs_in_tx > 1

    @property
    def match_key(self) -> tuple:
        return (self.chain_id, self.recipient.lower(), self.token_symbol.upper())
