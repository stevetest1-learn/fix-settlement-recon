"""
fix_settlement_recon — reconcile FIX execution reports against on-chain
stablecoin settlement.

Drops into an existing FIX support engine as a module: obligations in from
the FIX side, events in from the chain side, classified breaks out to the
ops desk or an LLM agent.
"""

from .breaks import Break, BreakCode, RUNBOOK, Severity
from .chain_decode import (
    TRANSFER_SELECTOR,
    TRANSFER_TOPIC,
    classify_finality,
    decode_receipt,
    decode_transfer_calldata,
    detect_reorgs,
)
from .chains import CHAINS, TOKENS, get_chain, token_by_address, token_for_currency
from .fix_ingest import (
    StaticWalletDirectory,
    obligation_from_execution_report,
    obligations_from_messages,
    parse_fix,
)
from .instruct import (
    InstructionError,
    PreflightResult,
    SettlementInstruction,
    SettlementWindow,
    UnsignedTransaction,
    build_payment_run,
    build_transfer_calldata,
    build_unsigned_transaction,
    net_obligations,
    preflight,
    settlement_reference,
)
from .matcher import Match, ReconConfig, ReconciliationReport, reconcile
from .models import (
    ChainSettlementEvent,
    PrecisionError,
    SettlementObligation,
    SettlementState,
    Side,
    TokenAmount,
)

__version__ = "0.1.0"

__all__ = [
    "Break", "BreakCode", "RUNBOOK", "Severity",
    "TRANSFER_TOPIC", "TRANSFER_SELECTOR",
    "decode_receipt", "decode_transfer_calldata", "detect_reorgs", "classify_finality",
    "CHAINS", "TOKENS", "get_chain", "token_by_address", "token_for_currency",
    "parse_fix", "obligation_from_execution_report", "obligations_from_messages",
    "StaticWalletDirectory",
    "reconcile", "ReconConfig", "ReconciliationReport", "Match",
    "net_obligations", "settlement_reference", "build_transfer_calldata",
    "build_unsigned_transaction", "build_payment_run", "preflight",
    "SettlementInstruction", "UnsignedTransaction", "SettlementWindow",
    "PreflightResult", "InstructionError",
    "TokenAmount", "SettlementObligation", "ChainSettlementEvent",
    "SettlementState", "Side", "PrecisionError",
]
