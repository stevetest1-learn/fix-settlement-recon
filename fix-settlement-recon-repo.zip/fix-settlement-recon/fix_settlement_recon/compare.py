"""
Field-level comparison between a FIX obligation and its chain settlement.

The reconciler decides whether two things match. This decides *which fields*
justify that decision, which is what an analyst actually needs when asked
"why did you mark this settled?" or "where exactly is the break?"

Four outcomes per row, and the asymmetric ones carry as much information as
the matched ones:

  matched     both sides present and agreeing
  broken      both present, disagreeing — the break lives here
  fix_only    a FIX field with no chain counterpart (ExecID, TransactTime)
  chain_only  a chain field with no FIX counterpart (block, gas, finality)

The fix_only and chain_only rows are the interesting part. They are the
places where the two models of settlement genuinely do not correspond, not
just places where data is missing. FIX has no field for "settled, but three
confirmations deep"; the chain has no field for "the venue booked this at
14:31:12.500". Rendering them as absences rather than hiding them is what
makes the mapping honest.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any

from .chains import get_chain
from .models import ChainSettlementEvent, SettlementObligation, SettlementState

MATCHED = "matched"
BROKEN = "broken"
FIX_ONLY = "fix_only"
CHAIN_ONLY = "chain_only"


@dataclass
class FieldPair:
    """One row of the comparison."""
    label: str
    status: str
    fix_ref: str = ""        # e.g. "119 SettlCurrAmt"
    fix_value: str = ""
    chain_ref: str = ""      # e.g. "log data"
    chain_value: str = ""
    note: str = ""

    def as_dict(self) -> dict[str, str]:
        return {
            "label": self.label, "status": self.status,
            "fix_ref": self.fix_ref, "fix_value": self.fix_value,
            "chain_ref": self.chain_ref, "chain_value": self.chain_value,
            "note": self.note,
        }


@dataclass
class Comparison:
    reference: str
    method: str
    confidence: float
    rows: list[FieldPair] = field(default_factory=list)
    obligation_ids: list[str] = field(default_factory=list)
    event_id: str = ""

    @property
    def is_clean(self) -> bool:
        return not any(r.status == BROKEN for r in self.rows)

    def as_dict(self) -> dict[str, Any]:
        return {
            "reference": self.reference,
            "method": self.method,
            "confidence": self.confidence,
            "obligation_ids": self.obligation_ids,
            "event_id": self.event_id,
            "clean": self.is_clean,
            "rows": [r.as_dict() for r in self.rows],
        }


def _short(addr: str) -> str:
    return f"{addr[:10]}…{addr[-4:]}" if len(addr) > 20 else addr


def compare(
    obligations: list[SettlementObligation],
    event: ChainSettlementEvent,
    *,
    method: str = "",
    confidence: float = 0.0,
    tolerance_minor: int = 0,
) -> Comparison:
    """Pair the fields of one settlement against the fills it discharges."""
    if not obligations:
        raise ValueError("nothing to compare against")

    lead = obligations[0]
    netted = len(obligations) > 1
    total = sum(o.amount.raw for o in obligations)
    commission = sum(o.commission.raw for o in obligations if o.commission)
    chain = get_chain(event.chain_id)

    rows: list[FieldPair] = []

    # --- identity: the field with no counterpart at all ---------------
    rows.append(FieldPair(
        label="Execution ID",
        status=FIX_ONLY,
        fix_ref="17 ExecID",
        fix_value=", ".join(o.obligation_id for o in obligations),
        note="The chain has never heard of an ExecID. This absence is why "
             "matching is tiered rather than a join.",
    ))
    rows.append(FieldPair(
        label="Transaction",
        status=CHAIN_ONLY,
        chain_ref="tx hash + log index",
        chain_value=f"{_short(event.tx_hash)}#{event.log_index}",
        note="One transaction can carry many settlements, so the log index is "
             "part of the key." if event.is_batch else "",
    ))

    # --- amount: the row that matters most -----------------------------
    delta = event.amount.raw - total
    if abs(delta) <= tolerance_minor:
        amount_status, note = MATCHED, ""
    elif commission and abs(delta) == commission:
        amount_status = MATCHED
        note = f"Short by exactly the booked commission ({_fmt(commission, event)})."
    else:
        amount_status = BROKEN
        exp = _power_of_ten(total, event.amount.raw)
        note = (
            f"Differs by exactly 10^{exp} — the signature of a decimals bug, "
            f"not a real difference in value."
            if exp is not None else
            f"Unexplained residual of {_fmt(delta, event)}."
        )
    rows.append(FieldPair(
        label="Settlement amount",
        status=amount_status,
        fix_ref="119 SettlCurrAmt" + (" (netted)" if netted else ""),
        fix_value=_fmt(total, event),
        chain_ref="Transfer log data",
        chain_value=str(event.amount),
        note=note,
    ))

    if commission:
        rows.append(FieldPair(
            label="Commission",
            status=FIX_ONLY,
            fix_ref="12 Commission",
            fix_value=_fmt(commission, event),
            note="Deducted before payment; no separate on-chain leg.",
        ))

    # --- currency and token --------------------------------------------
    rows.append(FieldPair(
        label="Settlement currency",
        status=MATCHED if event.token_symbol else BROKEN,
        fix_ref="120 SettlCurrency",
        fix_value=lead.fix_currency,
        chain_ref="token contract",
        chain_value=f"{event.token_symbol} ({_short(event.token_address)})",
        note="Resolved from the contract address, not from a name the token "
             "reports about itself.",
    ))

    # --- counterparty ---------------------------------------------------
    same_wallet = lead.counterparty_wallet.lower() == event.recipient.lower()
    rows.append(FieldPair(
        label="Counterparty wallet",
        status=MATCHED if same_wallet else BROKEN,
        fix_ref="settlement instruction",
        fix_value=_short(lead.counterparty_wallet),
        chain_ref="Transfer topics[2]",
        chain_value=_short(event.recipient),
        note="" if same_wallet else
             "Funds reached a different wallet than instructed. Escalate before "
             "adjusting either side.",
    ))
    rows.append(FieldPair(
        label="Paying wallet",
        status=CHAIN_ONLY,
        chain_ref="Transfer topics[1]",
        chain_value=_short(event.sender),
        note="The venue's omnibus wallet. FIX carries no payer address.",
    ))

    # --- timing ----------------------------------------------------------
    settled_on = event.block_timestamp.date()
    on_time = settled_on <= lead.settle_date
    rows.append(FieldPair(
        label="Settlement date",
        status=MATCHED if on_time else BROKEN,
        fix_ref="64 SettlDate",
        fix_value=lead.settle_date.isoformat(),
        chain_ref="block timestamp",
        chain_value=f"{event.block_timestamp:%Y-%m-%d %H:%M}Z",
        note="" if on_time else "Funds moved after the instructed date.",
    ))
    rows.append(FieldPair(
        label="Execution time",
        status=FIX_ONLY,
        fix_ref="60 TransactTime",
        fix_value=f"{lead.transact_time:%Y-%m-%d %H:%M:%S}Z"
                  + (f" (earliest of {len(obligations)})" if netted else ""),
        note="Venue-side only. The chain records when the payment landed, never "
             "when the trade happened.",
    ))

    # --- the part FIX cannot express -------------------------------------
    reverted = event.receipt_status == 0
    rows.append(FieldPair(
        label="Execution status",
        status=BROKEN if reverted else CHAIN_ONLY,
        chain_ref="receipt status",
        chain_value="0x0 — reverted" if reverted else "0x1 — succeeded",
        note="Mined and charged gas, but no value moved. Inclusion is not "
             "settlement." if reverted else
             "A transaction can be mined and still move nothing, so this is "
             "checked before the log is read.",
    ))

    final = event.state is SettlementState.FINAL
    policy = chain.finality
    rows.append(FieldPair(
        label="Finality",
        status=CHAIN_ONLY if final else BROKEN,
        chain_ref=f"{policy.model.value}",
        chain_value=(
            f"{event.state.value} · {event.confirmations} confirmation(s) "
            f"of {policy.final_confirmations}"
        ),
        note=(
            "Reaching this state trusts the sequencer; hard finality needs the "
            "challenge window."
            if policy.sequencer_trust_required and final else
            "" if final else
            "Matched, but not deep enough to release against."
        ),
    ))

    rows.append(FieldPair(
        label="Cost of settlement",
        status=CHAIN_ONLY,
        chain_ref="gas used × price",
        chain_value=f"{Decimal(event.gas_cost_wei).scaleb(-18):.6f} ETH",
        note="A real cost leg with no FIX representation at all.",
    ))

    return Comparison(
        reference=lead.settlement_ref or event.settlement_ref or event.event_id,
        method=method,
        confidence=confidence,
        rows=rows,
        obligation_ids=[o.obligation_id for o in obligations],
        event_id=event.event_id,
    )


def _fmt(minor: int, event: ChainSettlementEvent) -> str:
    return (
        f"{Decimal(minor).scaleb(-event.amount.decimals):,f} {event.amount.symbol}"
    )


def _power_of_ten(a: int, b: int) -> int | None:
    if a == 0 or b == 0:
        return None
    hi, lo = (a, b) if a > b else (b, a)
    if hi % lo:
        return None
    q, exp = hi // lo, 0
    while q % 10 == 0:
        q //= 10
        exp += 1
    return exp if q == 1 and exp > 0 else None
