"""
JSON-in / JSON-out adapter.

One entry point, ``run(payload) -> dict``, used by both the in-browser
Pyodide build and any server-side deployment. Keeping the adapter in the
library rather than in the page means the browser and a Lambda cannot
drift apart in how they interpret the same input.

Everything here is pure: no network, no clock beyond the report stamp, no
filesystem. The caller supplies receipts already fetched.
"""

from __future__ import annotations

import datetime as dt
from typing import Any

from .breaks import RUNBOOK, BreakCode
from .chain_decode import decode_receipt, detect_reorgs
from .chains import CHAINS, get_chain
from .compare import compare
from .fix_ingest import (
    FixParseError,
    StaticWalletDirectory,
    obligation_from_execution_report,
    parse_fix,
)
from .matcher import ReconConfig, reconcile
from .models import (
    ChainSettlementEvent,
    PrecisionError,
    SettlementObligation,
    TokenAmount,
)

TAG_ACCOUNT = 1
TAG_EXECID = 17


def split_messages(blob: str) -> list[str]:
    """One ExecutionReport per line. Blank and non-FIX lines are dropped."""
    out = []
    for line in blob.replace("\r", "").split("\n"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "35=" not in line:
            continue
        out.append(line)
    return out


def accounts_in(messages: list[str]) -> list[str]:
    """Distinct account IDs, so a UI can prompt for the wallets it needs."""
    seen: list[str] = []
    for m in messages:
        try:
            acct = parse_fix(m).get(TAG_ACCOUNT, "")
        except FixParseError:
            continue
        if acct and acct not in seen:
            seen.append(acct)
    return seen


def _amount_json(a: TokenAmount) -> dict[str, Any]:
    return {
        "raw": str(a.raw),          # str: minor units exceed JS safe integers
        "decimals": a.decimals,
        "symbol": a.symbol,
        "display": str(a),
    }


def _obligation_json(o: SettlementObligation) -> dict[str, Any]:
    return {
        "id": o.obligation_id,
        "account": o.account,
        "order_id": o.order_id,
        "cl_ord_id": o.cl_ord_id,
        "side": "BUY" if o.side.value == "1" else "SELL",
        "instrument": o.instrument,
        "amount": _amount_json(o.amount),
        "currency": o.fix_currency,
        "settle_date": o.settle_date.isoformat(),
        "transact_time": o.transact_time.isoformat(),
        "wallet": o.counterparty_wallet,
        "chain_id": o.chain_id,
        "commission": _amount_json(o.commission) if o.commission else None,
        "settlement_ref": o.settlement_ref,
    }


def _event_json(e: ChainSettlementEvent) -> dict[str, Any]:
    return {
        "id": e.event_id,
        "tx_hash": e.tx_hash,
        "log_index": e.log_index,
        "block_number": e.block_number,
        "block_hash": e.block_hash,
        "timestamp": e.block_timestamp.isoformat(),
        "chain_id": e.chain_id,
        "token": e.token_symbol,
        "token_address": e.token_address,
        "sender": e.sender,
        "recipient": e.recipient,
        "amount": _amount_json(e.amount),
        "status": e.receipt_status,
        "confirmations": e.confirmations,
        "state": e.state.value,
        "is_batch": e.is_batch,
        "gas_cost_wei": str(e.gas_cost_wei),
        "settlement_ref": e.settlement_ref,
    }


def _timestamp_for(
    receipt: dict[str, Any],
    supplied: dict[str, Any],
    fallback: dt.datetime,
) -> tuple[dt.datetime, bool]:
    """Resolve a block timestamp, reporting whether we had to guess.

    Guessing is acceptable in a debugging tool — you usually care about
    amounts and recipients, not the settlement window — but the caller is
    told, because a guessed timestamp silently changes window matching.
    """
    block = int(str(receipt.get("blockNumber", "0x0")), 16)
    for key in (str(block), hex(block)):
        if key in supplied:
            raw = supplied[key]
            if isinstance(raw, str) and not raw.isdigit():
                return dt.datetime.fromisoformat(raw), False
            return dt.datetime.fromtimestamp(int(raw), dt.timezone.utc), False
    if "timestamp" in receipt:
        return dt.datetime.fromtimestamp(
            int(str(receipt["timestamp"]), 16), dt.timezone.utc
        ), False
    return fallback, True


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Reconcile a batch. Never raises — errors come back in the response.

    Expected payload::

        {
          "fix": "<newline-separated ExecutionReports>",
          "wallets": {"ACME-FX": "0x2222..."},
          "receipts": [ <eth_getTransactionReceipt result>, ... ],
          "block_timestamps": {"21000000": 1754923200},
          "current_block": 21000500,
          "chain_id": 1,
          "canonical_block_hashes": {"21000000": "0x..."},
          "config": {"amount_tolerance_minor": 25000000,
                     "settlement_window_days": 2,
                     "require_final": true,
                     "enable_netting": true}
        }
    """
    warnings: list[str] = []
    try:
        chain_id = int(payload.get("chain_id", 1))
        if chain_id not in CHAINS:
            return {
                "ok": False,
                "error": f"Chain {chain_id} is not in the registry. "
                         f"Known chains: {', '.join(str(c) for c in CHAINS)}.",
            }

        messages = split_messages(payload.get("fix", "") or "")
        wallets_in = payload.get("wallets") or {}

        directory = StaticWalletDirectory()
        for account, wallet in wallets_in.items():
            if isinstance(wallet, dict):          # {"ACME": {"1": "0x.."}}
                for cid, addr in wallet.items():
                    directory.register(account, int(cid), addr)
            else:
                directory.register(account, chain_id, wallet)

        # --- FIX side -------------------------------------------------
        obligations: list[SettlementObligation] = []
        rejects: list[dict[str, str]] = []
        missing_wallets: list[str] = []

        for msg in messages:
            try:
                tags = parse_fix(msg)
            except FixParseError as exc:
                rejects.append({"ref": "?", "reason": str(exc)})
                continue
            ref = tags.get(TAG_EXECID) or tags.get(TAG_ACCOUNT) or "?"
            account = tags.get(TAG_ACCOUNT, "")
            if account and directory.wallet_for(account, chain_id) is None:
                if account not in missing_wallets:
                    missing_wallets.append(account)
                rejects.append({
                    "ref": ref,
                    "reason": f"No settlement wallet mapped for account {account}.",
                    "account": account,
                })
                continue
            try:
                ob = obligation_from_execution_report(msg, directory, chain_id)
            except (FixParseError, PrecisionError, ValueError) as exc:
                rejects.append({"ref": ref, "reason": str(exc)})
                continue
            if ob is not None:
                obligations.append(ob)

        # --- chain side -----------------------------------------------
        receipts = payload.get("receipts") or []
        if isinstance(receipts, dict):
            receipts = [receipts]

        supplied_ts = {str(k): v for k, v in (payload.get("block_timestamps") or {}).items()}
        fallback_ts = (
            min(o.transact_time for o in obligations)
            if obligations
            else dt.datetime.now(dt.timezone.utc)
        )

        current_block = payload.get("current_block")
        current_block = int(current_block) if current_block else None
        if current_block is None and receipts:
            deepest = max(int(str(r.get("blockNumber", "0x0")), 16) for r in receipts)
            policy = get_chain(chain_id).finality
            current_block = deepest + policy.final_confirmations
            warnings.append(
                "No current block height given, so confirmation depth was assumed "
                "sufficient. Finality states are not real — supply current_block to "
                "check them."
            )

        events: list[ChainSettlementEvent] = []
        guessed_ts = False
        for r in receipts:
            if not isinstance(r, dict) or "blockNumber" not in r:
                rejects.append({
                    "ref": str(r)[:40],
                    "reason": "Not a transaction receipt — expected the object returned "
                              "by eth_getTransactionReceipt.",
                })
                continue
            ts, guessed = _timestamp_for(r, supplied_ts, fallback_ts)
            guessed_ts = guessed_ts or guessed
            try:
                events += decode_receipt(r, ts, chain_id, current_block)
            except (KeyError, ValueError, TypeError) as exc:
                rejects.append({
                    "ref": str(r.get("transactionHash", "?"))[:20],
                    "reason": f"Could not decode receipt: {exc}",
                })
        if guessed_ts:
            warnings.append(
                "Some receipts had no block timestamp, so the earliest fill time was "
                "used. Settlement-window and late-settlement checks are unreliable "
                "for those."
            )

        canonical = {
            int(str(k), 0): v
            for k, v in (payload.get("canonical_block_hashes") or {}).items()
        }
        if canonical:
            detect_reorgs(events, canonical)

        # --- reconcile ------------------------------------------------
        cfg_in = payload.get("config") or {}
        cfg = ReconConfig(
            amount_tolerance_minor=int(cfg_in.get("amount_tolerance_minor", 0)),
            settlement_window=dt.timedelta(
                days=float(cfg_in.get("settlement_window_days", 2))
            ),
            enable_netting=bool(cfg_in.get("enable_netting", True)),
            require_final=bool(cfg_in.get("require_final", True)),
            allow_fee_residual=bool(cfg_in.get("allow_fee_residual", True)),
        )
        report = reconcile(obligations, events, cfg)

        by_ob = {o.obligation_id: o for o in obligations}
        by_ev = {e.event_id: e for e in events}
        comparisons = []
        for m in report.matches:
            try:
                comparisons.append(compare(
                    list(m.obligations), m.event,
                    method=m.method, confidence=m.confidence,
                    tolerance_minor=cfg.amount_tolerance_minor,
                ).as_dict())
            except (ValueError, KeyError):
                continue

        # Misdirected funds never become a match, but that pairing is exactly
        # where an analyst needs the field view — so build it from the break.
        for b in report.breaks:
            if b.code.value != "WRONG_RECIPIENT":
                continue
            obs_ = [by_ob[i] for i in b.obligation_ids if i in by_ob]
            ev = by_ev.get(b.event_ids[0]) if b.event_ids else None
            if obs_ and ev:
                try:
                    comparisons.append(compare(
                        obs_, ev, method="suspected", confidence=0.0,
                        tolerance_minor=cfg.amount_tolerance_minor,
                    ).as_dict())
                except (ValueError, KeyError):
                    continue

        return {
            "ok": True,
            "chain": get_chain(chain_id).name,
            "finality_model": get_chain(chain_id).finality.model.value,
            "sequencer_trust_required": get_chain(chain_id).finality.sequencer_trust_required,
            "summary": report.summary(),
            "counts": {
                "obligations": len(obligations),
                "events": len(events),
                "matches": len(report.matches),
                "breaks": len(report.breaks),
                "critical": len(report.critical),
                "warning": sum(1 for b in report.breaks if b.severity.value == "warning"),
                "info": sum(1 for b in report.breaks if b.severity.value == "info"),
                "rejects": len(rejects),
            },
            "obligations": [_obligation_json(o) for o in obligations],
            "events": [_event_json(e) for e in events],
            "comparisons": comparisons,
            "matches": [
                {
                    "method": m.method,
                    "confidence": m.confidence,
                    "obligation_ids": [o.obligation_id for o in m.obligations],
                    "event_id": m.event.event_id,
                    "residual_minor": str(m.residual_minor),
                }
                for m in report.matches
            ],
            "breaks": [
                {
                    "code": b.code.value,
                    "severity": b.severity.value,
                    "detail": b.detail,
                    "meaning": b.meaning,
                    "action": b.action,
                    "obligation_ids": b.obligation_ids,
                    "event_ids": b.event_ids,
                    "context": {k: str(v) for k, v in b.context.items()},
                }
                for b in report.breaks
            ],
            "gas_cost_wei": str(report.gas_cost_wei),
            "rejects": rejects,
            "missing_wallets": missing_wallets,
            "warnings": warnings,
            "agent_context": report.to_agent_context(),
        }

    except Exception as exc:  # last resort: a tool that 500s teaches nothing
        return {
            "ok": False,
            "error": f"{type(exc).__name__}: {exc}",
            "warnings": warnings,
        }


def runbook() -> list[dict[str, str]]:
    """The full break catalogue, for rendering a reference page."""
    return [
        {
            "code": code.value,
            "severity": sev.value,
            "meaning": meaning,
            "action": action,
        }
        for code, (sev, meaning, action) in RUNBOOK.items()
    ]
