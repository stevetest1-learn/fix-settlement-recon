"""
Chain + token reference data, and the finality policy that goes with it.

Two things worth being explicit about, because they are where naive
implementations get settlement wrong:

1. Decimals are per-token, not per-chain, and USDC is 6 — not 18.
   Everything internal is integer minor units. No floats anywhere.

2. "Finality" is not one thing. Post-Merge Ethereum has real economic
   finality via Casper FFG, so counting 12 confirmations is a pre-Merge
   habit — you should be asking the consensus layer for the `finalized`
   block tag instead. Optimistic rollups (Base, Arbitrum) have a
   three-stage model: instant soft confirmation from a centralised
   sequencer, then L1 batch inclusion, then a 7-day fraud-proof window.
   Institutions do not wait 7 days; they accept at L1 batch inclusion
   and carry explicit sequencer risk. That is a credit decision, not a
   technical one, and it belongs in reference data where risk can see it.

ADDRESSES MUST BE VERIFIED before production use. Load them from your
reference-data service, not from a source file someone pasted into.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class FinalityModel(str, Enum):
    CASPER_FFG = "casper_ffg"          # L1 Ethereum: justified -> finalized epochs
    OPTIMISTIC_ROLLUP = "optimistic"   # sequencer -> L1 batch -> challenge window
    ZK_ROLLUP = "zk_rollup"            # sequencer -> validity proof on L1
    PROBABILISTIC = "probabilistic"    # PoW-style confirmation counting


@dataclass(frozen=True)
class FinalityPolicy:
    model: FinalityModel
    #: confirmations after which we mark PROVISIONAL (safe to acknowledge)
    provisional_confirmations: int
    #: confirmations after which we mark FINAL (safe to release against)
    final_confirmations: int
    #: rough wall-clock seconds to reach FINAL, for SLA and ageing reports
    expected_seconds_to_final: int
    #: True if reaching FINAL depends on trusting a centralised sequencer
    sequencer_trust_required: bool = False
    notes: str = ""


@dataclass(frozen=True)
class Chain:
    chain_id: int
    name: str
    native_symbol: str
    native_decimals: int
    finality: FinalityPolicy
    avg_block_seconds: float


@dataclass(frozen=True)
class Token:
    symbol: str
    address: str          # lowercase, no checksum, for comparison
    decimals: int
    chain_id: int
    #: FIX Currency (tag 15/120) this token settles. Several tokens can
    #: map to the same currency — that is the point of the indirection.
    fix_currency: str


ETHEREUM = Chain(
    chain_id=1,
    name="Ethereum Mainnet",
    native_symbol="ETH",
    native_decimals=18,
    avg_block_seconds=12.0,
    finality=FinalityPolicy(
        model=FinalityModel.CASPER_FFG,
        provisional_confirmations=2,
        final_confirmations=64,   # ~2 epochs; prefer the `finalized` tag when available
        expected_seconds_to_final=13 * 60,
        notes="Use eth_getBlockByNumber('finalized') rather than counting. "
              "Confirmation counts here are a fallback only.",
    ),
)

BASE = Chain(
    chain_id=8453,
    name="Base",
    native_symbol="ETH",
    native_decimals=18,
    avg_block_seconds=2.0,
    finality=FinalityPolicy(
        model=FinalityModel.OPTIMISTIC_ROLLUP,
        provisional_confirmations=1,
        final_confirmations=1,
        expected_seconds_to_final=20 * 60,
        sequencer_trust_required=True,
        notes="Hard finality requires the 7-day challenge window. Institutional "
              "practice accepts at L1 batch inclusion and books sequencer risk.",
    ),
)

ARBITRUM = Chain(
    chain_id=42161,
    name="Arbitrum One",
    native_symbol="ETH",
    native_decimals=18,
    avg_block_seconds=0.25,
    finality=FinalityPolicy(
        model=FinalityModel.OPTIMISTIC_ROLLUP,
        provisional_confirmations=1,
        final_confirmations=1,
        expected_seconds_to_final=20 * 60,
        sequencer_trust_required=True,
        notes="Same challenge-window caveat as Base.",
    ),
)

CHAINS: dict[int, Chain] = {c.chain_id: c for c in (ETHEREUM, BASE, ARBITRUM)}


# Canonical stablecoins. VERIFY THESE against the issuer's published
# contract list before you trust a cent to them.
TOKENS: tuple[Token, ...] = (
    Token("USDC", "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48", 6, 1, "USD"),
    Token("USDT", "0xdac17f958d2ee523a2206206994597c13d831ec7", 6, 1, "USD"),
    Token("USDC", "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913", 6, 8453, "USD"),
    Token("USDC", "0xaf88d065e77c8cc2239327c5edb3a432268e5831", 6, 42161, "USD"),
)

_BY_ADDRESS: dict[tuple[int, str], Token] = {
    (t.chain_id, t.address): t for t in TOKENS
}
_BY_CURRENCY: dict[tuple[int, str], Token] = {}
for _t in TOKENS:
    # First registration wins; USDT does not displace USDC as the default
    # USD settlement token on Ethereum.
    _BY_CURRENCY.setdefault((_t.chain_id, _t.fix_currency), _t)


def get_chain(chain_id: int) -> Chain:
    try:
        return CHAINS[chain_id]
    except KeyError:
        raise KeyError(f"unknown chain_id {chain_id}; add it to the registry") from None


def token_by_address(chain_id: int, address: str) -> Token | None:
    return _BY_ADDRESS.get((chain_id, address.lower()))


def token_for_currency(chain_id: int, fix_currency: str) -> Token | None:
    """Resolve a FIX Currency (tag 120 SettlCurrency) to a settlement token."""
    return _BY_CURRENCY.get((chain_id, fix_currency.upper()))


def is_known_token(chain_id: int, address: str) -> bool:
    return (chain_id, address.lower()) in _BY_ADDRESS
