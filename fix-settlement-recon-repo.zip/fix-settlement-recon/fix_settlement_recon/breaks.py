"""
Break taxonomy.

A reconciler that returns a boolean is useless to an operations desk.
What the desk needs at 3am is: what broke, how bad, and what do I do
next. So every break carries a severity and a first action, and the
codes are stable strings you can build alerting and SLAs against.

This is the part that turns a matching script into something that could
actually sit in a production support rota.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Severity(str, Enum):
    INFO = "info"          # explained, no action
    WARNING = "warning"    # investigate within the day
    CRITICAL = "critical"  # stop and escalate; money may be wrong


class BreakCode(str, Enum):
    NO_CHAIN_EVENT = "NO_CHAIN_EVENT"
    NO_FIX_OBLIGATION = "NO_FIX_OBLIGATION"
    AMOUNT_MISMATCH = "AMOUNT_MISMATCH"
    FEE_EXPLAINED_RESIDUAL = "FEE_EXPLAINED_RESIDUAL"
    DECIMAL_SCALE_SUSPECT = "DECIMAL_SCALE_SUSPECT"
    WRONG_RECIPIENT = "WRONG_RECIPIENT"
    WRONG_TOKEN = "WRONG_TOKEN"
    WRONG_CHAIN = "WRONG_CHAIN"
    TX_REVERTED = "TX_REVERTED"
    LATE_SETTLEMENT = "LATE_SETTLEMENT"
    NOT_YET_FINAL = "NOT_YET_FINAL"
    REORGED = "REORGED"
    AMBIGUOUS_MATCH = "AMBIGUOUS_MATCH"
    DUPLICATE_SETTLEMENT = "DUPLICATE_SETTLEMENT"
    PARTIAL_NETTING = "PARTIAL_NETTING"
    UNSUPPORTED_PRECISION = "UNSUPPORTED_PRECISION"


#: code -> (severity, what it means, first action for the desk)
RUNBOOK: dict[BreakCode, tuple[Severity, str, str]] = {
    BreakCode.NO_CHAIN_EVENT: (
        Severity.WARNING,
        "A fill created a settlement obligation but no matching on-chain transfer was found.",
        "Check whether the payment was submitted at all. If it is in the mempool, it is "
        "pending, not missing — widen the search window before escalating to treasury.",
    ),
    BreakCode.NO_FIX_OBLIGATION: (
        Severity.CRITICAL,
        "Value left a firm wallet with no fill to justify it.",
        "Treat as a potential unauthorised movement. Freeze further outbound from this "
        "wallet and escalate to security before assuming it is a data gap.",
    ),
    BreakCode.AMOUNT_MISMATCH: (
        Severity.CRITICAL,
        "Obligation and transfer matched on counterparty and timing but the amounts differ.",
        "Do not release. Confirm the residual against fees and any netting group before "
        "adjusting either side.",
    ),
    BreakCode.FEE_EXPLAINED_RESIDUAL: (
        Severity.INFO,
        "Transfer is short by exactly the commission on the fill.",
        "No action. Confirm the fee booking model is net-of-commission.",
    ),
    BreakCode.DECIMAL_SCALE_SUSPECT: (
        Severity.CRITICAL,
        "The two amounts differ by an exact power of ten — the signature of a decimals bug.",
        "Check the token's decimals in reference data. USDC is 6, not 18. Do not 'fix' this "
        "by adjusting the amount; fix the scaling and re-run.",
    ),
    BreakCode.WRONG_RECIPIENT: (
        Severity.CRITICAL,
        "The amount and timing match an obligation, but the funds went to a different wallet.",
        "Escalate immediately. This is either stale wallet reference data or misdirected funds.",
    ),
    BreakCode.WRONG_TOKEN: (
        Severity.CRITICAL,
        "Settlement currency on the fill does not match the token actually transferred.",
        "Verify the token contract address. Confirm this is not a spoofed contract using a "
        "well-known symbol.",
    ),
    BreakCode.WRONG_CHAIN: (
        Severity.WARNING,
        "Settlement landed on a different chain than the instruction specified.",
        "Confirm the counterparty accepts delivery on this chain and that the finality "
        "assumptions were repapered.",
    ),
    BreakCode.TX_REVERTED: (
        Severity.CRITICAL,
        "The transaction was mined and consumed gas but moved nothing.",
        "Nothing settled. Inclusion is not settlement. Resubmit and check the failure reason.",
    ),
    BreakCode.LATE_SETTLEMENT: (
        Severity.WARNING,
        "Funds moved after the instructed settlement date.",
        "Record for the counterparty's settlement performance stats; check for claims.",
    ),
    BreakCode.NOT_YET_FINAL: (
        Severity.INFO,
        "Transfer matched but has not reached the chain's finality threshold.",
        "Do not release against it yet. Re-poll; this clears itself with depth.",
    ),
    BreakCode.REORGED: (
        Severity.CRITICAL,
        "A previously observed settlement is no longer in the canonical chain.",
        "If anything was released against this, you are now short. Reverse the settlement "
        "status and escalate to treasury and risk.",
    ),
    BreakCode.AMBIGUOUS_MATCH: (
        Severity.WARNING,
        "More than one transfer is an equally good candidate for this obligation.",
        "Do not auto-match. Require a settlement reference from the venue to disambiguate.",
    ),
    BreakCode.DUPLICATE_SETTLEMENT: (
        Severity.CRITICAL,
        "One obligation appears to have been settled more than once.",
        "Potential double payment. Halt the payment run and reconcile the wallet balance.",
    ),
    BreakCode.PARTIAL_NETTING: (
        Severity.WARNING,
        "A netting group does not fully account for the transfer that discharged it.",
        "Identify the missing fills. The transfer is probably correct and the fill feed "
        "incomplete.",
    ),
    BreakCode.UNSUPPORTED_PRECISION: (
        Severity.CRITICAL,
        "The instructed amount cannot be represented in the token's minor units.",
        "Reject the instruction upstream. You cannot settle a fraction of a minor unit.",
    ),
}


@dataclass
class Break:
    code: BreakCode
    obligation_ids: list[str] = field(default_factory=list)
    event_ids: list[str] = field(default_factory=list)
    detail: str = ""
    context: dict[str, Any] = field(default_factory=dict)

    @property
    def severity(self) -> Severity:
        return RUNBOOK[self.code][0]

    @property
    def meaning(self) -> str:
        return RUNBOOK[self.code][1]

    @property
    def action(self) -> str:
        return RUNBOOK[self.code][2]

    def __str__(self) -> str:
        who = ", ".join(self.obligation_ids + self.event_ids) or "-"
        return f"[{self.severity.value.upper():8}] {self.code.value:24} {who}  {self.detail}"
