"""
Receipt / log decoding. Deliberately pure — no network calls in here.

That separation is what makes the reconciler testable offline: you can
replay a captured receipt and assert on the outcome without an RPC key,
which matters both for CI and for a reviewer who wants to run this
without signing up for anything.

Decoding rules that trip people up:

  * ``to`` on the transaction is the *token contract*, not the recipient.
    The recipient lives in calldata. Reconciling on ``to`` reconciles
    against the wrong party every time.
  * Indexed event parameters live in ``topics``; non-indexed ones live in
    ``data``. For ERC-20 Transfer that means from/to are topics and the
    amount is data.
  * ``status: 0x0`` means mined, gas burned, nothing moved. Presence in a
    block is not settlement.
  * One transaction can carry many Transfer logs. ``tx_hash`` is not a
    unique key for a settlement; ``tx_hash + log_index`` is.
"""

from __future__ import annotations

import datetime as dt
from typing import Any, Iterable

from .chains import get_chain, token_by_address
from .keccak import event_topic, function_selector
from .models import ChainSettlementEvent, SettlementState, TokenAmount

# Derived, not pasted. If these are wrong the tests fail immediately.
TRANSFER_TOPIC = event_topic("Transfer(address,address,uint256)")
TRANSFER_SELECTOR = function_selector("transfer(address,uint256)")
TRANSFER_FROM_SELECTOR = function_selector("transferFrom(address,address,uint256)")


def _to_int(value: Any) -> int:
    if isinstance(value, int):
        return value
    return int(str(value), 16)


def _topic_to_address(topic: str) -> str:
    """A 32-byte topic holds a 20-byte address, left-padded with zeros."""
    raw = topic.removeprefix("0x").rjust(64, "0")
    return "0x" + raw[-40:].lower()


def decode_transfer_calldata(input_data: str) -> dict[str, Any] | None:
    """Decode ``transfer``/``transferFrom`` calldata.

    Useful as a statement of *intent* even when the transaction reverted
    and therefore emitted no log — that is exactly the case where you need
    to know what someone tried to do.
    """
    data = input_data.removeprefix("0x")
    if len(data) < 8:
        return None
    selector = "0x" + data[:8]
    args = data[8:]

    if selector == TRANSFER_SELECTOR and len(args) >= 128:
        return {
            "method": "transfer",
            "to": "0x" + args[24:64].lower(),
            "amount": int(args[64:128], 16),
        }
    if selector == TRANSFER_FROM_SELECTOR and len(args) >= 192:
        return {
            "method": "transferFrom",
            "from": "0x" + args[24:64].lower(),
            "to": "0x" + args[88:128].lower(),
            "amount": int(args[128:192], 16),
        }
    return None


def decode_receipt(
    receipt: dict[str, Any],
    block_timestamp: dt.datetime,
    chain_id: int,
    current_block: int | None = None,
    *,
    only_known_tokens: bool = True,
) -> list[ChainSettlementEvent]:
    """Turn an ``eth_getTransactionReceipt`` result into settlement events.

    A reverted receipt yields a single synthetic REVERTED event so the
    failure is visible to reconciliation rather than looking like a
    missing payment.
    """
    status = _to_int(receipt.get("status", "0x1"))
    block_number = _to_int(receipt["blockNumber"])
    block_hash = receipt.get("blockHash", "")
    tx_hash = receipt["transactionHash"]

    gas_used = _to_int(receipt.get("gasUsed", 0))
    gas_price = _to_int(receipt.get("effectiveGasPrice", 0))
    gas_cost_wei = gas_used * gas_price

    confirmations = 0
    if current_block is not None:
        confirmations = max(0, current_block - block_number + 1)

    if status == 0:
        intent = decode_transfer_calldata(receipt.get("input", "0x")) or {}
        return [
            ChainSettlementEvent(
                tx_hash=tx_hash,
                log_index=0,
                block_number=block_number,
                block_hash=block_hash,
                block_timestamp=block_timestamp,
                chain_id=chain_id,
                token_address=str(receipt.get("to", "")).lower(),
                token_symbol="",
                sender=str(receipt.get("from", "")).lower(),
                recipient=str(intent.get("to", "")).lower(),
                amount=TokenAmount(int(intent.get("amount", 0)), 6, ""),
                receipt_status=0,
                gas_cost_wei=gas_cost_wei,
                confirmations=confirmations,
                state=SettlementState.REVERTED,
            )
        ]

    logs = receipt.get("logs", []) or []
    transfer_logs = [
        lg for lg in logs
        if (lg.get("topics") or [""])[0].lower() == TRANSFER_TOPIC.lower()
        and len(lg.get("topics", [])) >= 3
    ]

    events: list[ChainSettlementEvent] = []
    for lg in transfer_logs:
        token_address = str(lg["address"]).lower()
        token = token_by_address(chain_id, token_address)
        if token is None and only_known_tokens:
            # Unrecognised contract. Could be an airdrop-spam token using a
            # familiar symbol; do not let it into settlement.
            continue

        decimals = token.decimals if token else 18
        symbol = token.symbol if token else "UNKNOWN"
        topics = lg["topics"]

        events.append(
            ChainSettlementEvent(
                tx_hash=tx_hash,
                log_index=_to_int(lg.get("logIndex", 0)),
                block_number=block_number,
                block_hash=block_hash,
                block_timestamp=block_timestamp,
                chain_id=chain_id,
                token_address=token_address,
                token_symbol=symbol,
                sender=_topic_to_address(topics[1]),
                recipient=_topic_to_address(topics[2]),
                amount=TokenAmount(_to_int(lg.get("data", "0x0")), decimals, symbol),
                receipt_status=1,
                # Gas is a property of the transaction, not the log. Attribute it
                # once, to the first leg, so a batch is not charged N times.
                gas_cost_wei=gas_cost_wei if not events else 0,
                confirmations=confirmations,
                state=SettlementState.OBSERVED,
                logs_in_tx=len(transfer_logs),
            )
        )

    for ev in events:
        ev.state = classify_finality(ev, chain_id)
    return events


def classify_finality(event: ChainSettlementEvent, chain_id: int) -> SettlementState:
    """Apply the chain's finality policy to an event's depth."""
    if event.receipt_status == 0:
        return SettlementState.REVERTED
    if event.state is SettlementState.REORGED:
        return SettlementState.REORGED

    policy = get_chain(chain_id).finality
    if event.confirmations >= policy.final_confirmations:
        return SettlementState.FINAL
    if event.confirmations >= policy.provisional_confirmations:
        return SettlementState.PROVISIONAL
    return SettlementState.OBSERVED


def detect_reorgs(
    known_events: Iterable[ChainSettlementEvent],
    canonical_block_hashes: dict[int, str],
) -> list[ChainSettlementEvent]:
    """Flag events whose block is no longer canonical.

    Call this on every polling cycle against the events you have already
    recorded. An event you marked FINAL and then released against is the
    one that hurts, which is why REORGED is a critical break rather than
    a quiet state change.
    """
    reorged: list[ChainSettlementEvent] = []
    for ev in known_events:
        canonical = canonical_block_hashes.get(ev.block_number)
        if canonical is not None and canonical.lower() != ev.block_hash.lower():
            ev.state = SettlementState.REORGED
            reorged.append(ev)
    return reorged
