"""
FIX ExecutionReport -> SettlementObligation.

Only fills matter here: MsgType 8 with OrdStatus 1 (Partially filled) or
2 (Filled). Everything else is order state, not a cash obligation.

Wallet resolution deliberately goes through an injectable directory
rather than trusting a tag on the wire. A settlement wallet arriving in
an inbound message is an instruction from a counterparty about where to
send money — that belongs in controlled reference data with a
maker-checker around changes, not in whatever the last message said.
"""

from __future__ import annotations

import datetime as dt
from decimal import Decimal
from typing import Iterable, Protocol

from .chains import token_for_currency
from .models import (
    PrecisionError,
    Side,
    SettlementObligation,
    TokenAmount,
)

SOH = "\x01"

# Standard tags
TAG_MSGTYPE = 35
TAG_ACCOUNT = 1
TAG_CLORDID = 11
TAG_ORDERID = 37
TAG_EXECID = 17
TAG_ORDSTATUS = 39
TAG_SIDE = 54
TAG_SYMBOL = 55
TAG_LASTQTY = 32
TAG_LASTPX = 31
TAG_COMMISSION = 12
TAG_SETTLCURRAMT = 119
TAG_SETTLCURRENCY = 120
TAG_SETTLDATE = 64
TAG_TRANSACTTIME = 60

# User-defined tags (>= 5000 is the reserved range). These are placeholders:
# in a real venue integration the chain and reference usually arrive in a
# Parties repeating group (448/447/452) or in strategy parameters (957-960).
TAG_SETTL_CHAIN_ID = 20002
TAG_SETTL_REF = 20003

FILLED_STATUSES = {"1", "2"}  # partially filled, filled


class WalletDirectory(Protocol):
    """Maps a trading account to its settlement wallet on a given chain."""

    def wallet_for(self, account: str, chain_id: int) -> str | None: ...


class StaticWalletDirectory:
    """Reference data held in memory. Back this with your SSI service."""

    def __init__(self, mapping: dict[tuple[str, int], str] | None = None) -> None:
        self._m = {(a, c): w.lower() for (a, c), w in (mapping or {}).items()}

    def register(self, account: str, chain_id: int, wallet: str) -> None:
        self._m[(account, chain_id)] = wallet.lower()

    def wallet_for(self, account: str, chain_id: int) -> str | None:
        return self._m.get((account, chain_id))


class FixParseError(ValueError):
    pass


def parse_fix(message: str, delimiter: str = SOH) -> dict[int, str]:
    """Flat tag->value parse. Repeating groups collapse to last value.

    That is fine for settlement fields, which are top-level, and it keeps
    this readable. Real Parties handling needs a group-aware parser.
    """
    if delimiter not in message and "|" in message:
        delimiter = "|"  # tolerate the pipe-delimited form used in logs and tickets
    out: dict[int, str] = {}
    for field in message.strip().split(delimiter):
        if not field:
            continue
        tag, _, value = field.partition("=")
        if not _:
            continue
        try:
            out[int(tag)] = value
        except ValueError:
            continue
    if not out:
        raise FixParseError("no tags parsed; wrong delimiter?")
    return out


def _parse_transact_time(value: str) -> dt.datetime:
    """FIX UTCTimestamp, with or without sub-second precision."""
    for fmt in ("%Y%m%d-%H:%M:%S.%f", "%Y%m%d-%H:%M:%S"):
        try:
            return dt.datetime.strptime(value, fmt).replace(tzinfo=dt.timezone.utc)
        except ValueError:
            continue
    raise FixParseError(f"unparseable TransactTime: {value!r}")


def _parse_settl_date(value: str) -> dt.date:
    return dt.datetime.strptime(value, "%Y%m%d").date()


def obligation_from_execution_report(
    message: str | dict[int, str],
    directory: WalletDirectory,
    default_chain_id: int = 1,
) -> SettlementObligation | None:
    """Build an obligation from one ExecutionReport, or None if it is not a fill.

    Raises PrecisionError if the instructed amount cannot be expressed in the
    settlement token's minor units — that is a real break, caught at the door.
    """
    tags = parse_fix(message) if isinstance(message, str) else dict(message)

    if tags.get(TAG_MSGTYPE) != "8":
        return None
    if tags.get(TAG_ORDSTATUS) not in FILLED_STATUSES:
        return None

    chain_id = int(tags.get(TAG_SETTL_CHAIN_ID, default_chain_id))
    currency = tags.get(TAG_SETTLCURRENCY) or tags.get(15) or "USD"

    token = token_for_currency(chain_id, currency)
    if token is None:
        raise FixParseError(
            f"no settlement token registered for {currency} on chain {chain_id}"
        )

    if TAG_SETTLCURRAMT not in tags:
        raise FixParseError(
            f"ExecID {tags.get(TAG_EXECID)} has no SettlCurrAmt(119); "
            "cannot derive a cash obligation"
        )

    amount = TokenAmount.from_decimal_str(
        tags[TAG_SETTLCURRAMT], token.decimals, token.symbol
    )

    commission = None
    if TAG_COMMISSION in tags and Decimal(tags[TAG_COMMISSION]) != 0:
        try:
            commission = TokenAmount.from_decimal_str(
                tags[TAG_COMMISSION], token.decimals, token.symbol
            )
        except PrecisionError:
            commission = None  # sub-minor-unit fee; carry as unexplained residual

    account = tags.get(TAG_ACCOUNT, "")
    wallet = directory.wallet_for(account, chain_id)
    if wallet is None:
        raise FixParseError(
            f"no settlement wallet on chain {chain_id} for account {account!r}; "
            "settlement instruction is incomplete"
        )

    settle_date = (
        _parse_settl_date(tags[TAG_SETTLDATE])
        if TAG_SETTLDATE in tags
        else _parse_transact_time(tags[TAG_TRANSACTTIME]).date()
    )

    return SettlementObligation(
        obligation_id=tags.get(TAG_EXECID, ""),
        account=account,
        order_id=tags.get(TAG_ORDERID, ""),
        cl_ord_id=tags.get(TAG_CLORDID, ""),
        side=Side(tags.get(TAG_SIDE, "1")),
        instrument=tags.get(TAG_SYMBOL, ""),
        amount=amount,
        fix_currency=currency.upper(),
        settle_date=settle_date,
        transact_time=_parse_transact_time(tags[TAG_TRANSACTTIME]),
        counterparty_wallet=wallet,
        chain_id=chain_id,
        commission=commission,
        last_qty=Decimal(tags[TAG_LASTQTY]) if TAG_LASTQTY in tags else None,
        last_px=Decimal(tags[TAG_LASTPX]) if TAG_LASTPX in tags else None,
        settlement_ref=tags.get(TAG_SETTL_REF),
        raw=tags,
    )


def obligations_from_messages(
    messages: Iterable[str | dict[int, str]],
    directory: WalletDirectory,
    default_chain_id: int = 1,
) -> tuple[list[SettlementObligation], list[str]]:
    """Bulk ingest. Returns (obligations, rejection reasons).

    Rejections are returned rather than raised so one malformed message
    cannot stall an entire settlement run — but they are never silently
    dropped either.
    """
    obligations: list[SettlementObligation] = []
    rejects: list[str] = []
    for msg in messages:
        try:
            ob = obligation_from_execution_report(msg, directory, default_chain_id)
        except (FixParseError, PrecisionError, ValueError) as exc:
            rejects.append(str(exc))
            continue
        if ob is not None:
            obligations.append(ob)
    return obligations, rejects
