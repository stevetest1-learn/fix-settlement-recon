"""
Command-line entry point:  python3 -m fix_settlement_recon

Exit codes are meaningful, so this can sit in a cron job or a pipeline:

    0  reconciled clean (info-level breaks only)
    1  at least one critical or warning break
    2  bad input or usage error
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
from decimal import Decimal

from .webbridge import run, runbook

C = {
    "critical": "\033[31m", "warning": "\033[33m", "info": "\033[36m",
    "ok": "\033[32m", "dim": "\033[2m", "bold": "\033[1m", "off": "\033[0m",
}


def _paint(enabled: bool):
    return C if enabled else {k: "" for k in C}


def _demo_payload() -> dict:
    venue = "0x1111111111111111111111111111111111111111"
    acme = "0x2222222222222222222222222222222222222222"
    beta = "0x3333333333333333333333333333333333333333"
    other = "0x4444444444444444444444444444444444444444"
    usdc = "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
    topic = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"
    pad = lambda a: "0x" + a[2:].rjust(64, "0")
    ts = hex(int(dt.datetime(2026, 8, 11, 14, 40, tzinfo=dt.timezone.utc).timestamp()))

    def rcpt(tx, blk, legs, status="0x1"):
        return {
            "transactionHash": tx, "blockNumber": hex(blk),
            "blockHash": "0x" + format(blk, "064x"), "status": status,
            "from": venue, "to": usdc, "timestamp": ts,
            "gasUsed": hex(52000 + 26000 * (len(legs) - 1)),
            "effectiveGasPrice": "0x431bde00",
            "logs": [{"address": usdc, "topics": [topic, pad(venue), pad(to)],
                      "data": hex(amt), "logIndex": hex(i)}
                     for i, (to, amt) in enumerate(legs)],
        }

    def er(eid, acct, amt, **over):
        t = {35: "8", 39: "2", 17: eid, 37: "ORD-" + eid, 11: "CL-" + eid,
             1: acct, 54: "1", 55: "ETH/USD", 32: "2.5", 31: "3400.00",
             119: amt, 120: "USD", 64: "20260811",
             60: "20260811-14:30:00.000", 20002: "1"}
        t.update({int(k): v for k, v in over.items()})
        return "|".join(f"{k}={v}" for k, v in t.items())

    return {
        "fix": "\n".join([
            er("EX-1001", "ACME-FX", "3000.00"),
            er("EX-1002", "ACME-FX", "2500.00", **{"60": "20260811-14:31:12.500"}),
            er("EX-1003", "ACME-FX", "3000.00", **{"60": "20260811-14:33:47.100"}),
            er("EX-1004", "BETA-CAP", "12000.00", **{"12": "25.00"}),
            er("EX-1005", "BETA-CAP", "4750.00", **{"60": "20260811-15:02:00.000"}),
            er("EX-1006", "ACME-FX", "100.00000015"),
        ]),
        "wallets": {"ACME-FX": acme, "BETA-CAP": beta},
        "receipts": [
            rcpt("0xaa01", 21000000, [(acme, 8_500_000_000)]),
            rcpt("0xbb02", 21000100, [(beta, 11_975_000_000), (other, 900_000_000)]),
            rcpt("0xcc03", 21000200, [(beta, 4_750_000_000)], "0x0"),
        ],
        "chain_id": 1,
        "config": {"amount_tolerance_minor": 25_000_000},
    }


def _fetch(rpc_url: str, hashes: list[str], chain_id: int):
    from .rpc import JsonRpcClient
    client = JsonRpcClient(rpc_url, chain_id)
    head = client.block_number()
    receipts, stamps = [], {}
    for h in hashes:
        r = client.call("eth_getTransactionReceipt", [h])
        if r is None:
            print(f"no receipt for {h} — not mined, or wrong chain", file=sys.stderr)
            continue
        tx = client.call("eth_getTransactionByHash", [h]) or {}
        blk = client.call("eth_getBlockByNumber", [r["blockNumber"], False])
        r["input"] = tx.get("input", "0x")
        receipts.append(r)
        stamps[str(int(r["blockNumber"], 16))] = int(blk["timestamp"], 16)
    return receipts, stamps, head


def render(res: dict, c: dict, verbose: bool) -> None:
    for w in res.get("warnings", []):
        print(f"{c['warning']}note{c['off']}  {w}")
    if res.get("warnings"):
        print()

    n = res["counts"]
    print(f"{c['bold']}{res['chain']}{c['off']}  {c['dim']}finality: "
          f"{res['finality_model']}"
          f"{'  (sequencer trust required)' if res['sequencer_trust_required'] else ''}"
          f"{c['off']}")
    print(f"  {n['obligations']} obligation(s), {n['events']} transfer(s) -> "
          f"{c['ok']}{n['matches']} settlement(s) matched{c['off']}")
    print(f"  {c['critical']}{n['critical']} critical{c['off']}, "
          f"{c['warning']}{n['warning']} warning{c['off']}, "
          f"{c['info']}{n['info']} info{c['off']}"
          + (f", {n['rejects']} not ingested" if n["rejects"] else ""))
    print()

    if res["matches"]:
        print(f"{c['bold']}MATCHED{c['off']}")
        for m in res["matches"]:
            ids = ",".join(m["obligation_ids"])
            print(f"  {c['ok']}✓{c['off']} {m['method']:11} {c['dim']}conf "
                  f"{m['confidence']:.2f}{c['off']}  {ids} -> {m['event_id']}")
        print()

    order = {"critical": 0, "warning": 1, "info": 2}
    breaks = sorted(res["breaks"], key=lambda b: order[b["severity"]])
    if breaks:
        print(f"{c['bold']}BREAKS{c['off']}")
        for b in breaks:
            col = c[b["severity"]]
            refs = " ".join(b["obligation_ids"] + b["event_ids"])
            print(f"  {col}{b['severity'].upper():8}{c['off']} {b['code']}")
            print(f"           {b['detail']}")
            if refs:
                print(f"           {c['dim']}{refs}{c['off']}")
            if verbose:
                print(f"           {c['dim']}why : {b['meaning']}{c['off']}")
                print(f"           {c['dim']}do  : {b['action']}{c['off']}")
            print()

    if res["rejects"]:
        print(f"{c['bold']}NOT INGESTED{c['off']}")
        for r in res["rejects"]:
            print(f"  {c['warning']}·{c['off']} {r['ref']}: {r['reason']}")
        print()


def _instruct(payload: dict, a, c: dict) -> int:
    """Build same-day payment instructions instead of reconciling."""
    from .fix_ingest import StaticWalletDirectory, obligations_from_messages
    from .instruct import InstructionError, SettlementWindow, build_payment_run
    from .webbridge import split_messages

    if not a.from_wallet:
        print("--instruct needs --from-wallet (the treasury sending wallet)",
              file=sys.stderr)
        return 2

    directory = StaticWalletDirectory()
    for acct, w in payload["wallets"].items():
        directory.register(acct, payload["chain_id"], w)

    obligations, rejects = obligations_from_messages(
        split_messages(payload["fix"]), directory, payload["chain_id"]
    )
    for r in rejects:
        print(f"{c['warning']}skipped{c['off']}  {r}")
    if not obligations:
        print("No settleable fills found.", file=sys.stderr)
        return 2

    window = None
    now = dt.datetime.now(dt.timezone.utc)
    if a.cutoff:
        try:
            hh, mm = (int(x) for x in a.cutoff.split(":"))
        except ValueError:
            print("--cutoff must look like 21:00", file=sys.stderr)
            return 2
        anchor = min(o.transact_time for o in obligations)
        window = SettlementWindow(
            cutoff=anchor.replace(hour=hh, minute=mm, second=0, microsecond=0)
        )
        now = anchor

    try:
        ready, held = build_payment_run(
            obligations, sender=a.from_wallet, starting_nonce=a.nonce,
            base_fee_wei=a.base_fee, window=window, now=now,
        )
    except InstructionError as exc:
        print(f"cannot build payments: {exc}", file=sys.stderr)
        return 2

    if a.json:
        print(json.dumps({
            "ready": [{"instruction": {
                "reference": i.reference, "recipient": i.recipient,
                "amount": str(i.amount), "amount_minor": str(i.amount.raw),
                "discharges": i.obligation_ids,
                "settle_date": i.settle_date.isoformat()},
                "transaction": tx.to_dict(),
                "intent": tx.intent,
                "warnings": chk.warnings} for i, tx, chk in ready],
            "held": [{"reference": i.reference, "recipient": i.recipient,
                      "amount": str(i.amount), "blockers": chk.blockers}
                     for i, chk in held],
        }, indent=2))
        return 1 if held else 0

    total = sum(i.amount.raw for i, _, _ in ready)
    print(f"{c['bold']}PAYMENT RUN{c['off']}  "
          f"{len(obligations)} fill(s) -> {len(ready) + len(held)} payment(s)")
    if window:
        print(f"  {c['dim']}cutoff {window.cutoff:%H:%M}Z{c['off']}")
    print()

    for i, tx, chk in ready:
        print(f"  {c['ok']}READY{c['off']}    {i.reference}   {str(i.amount):>22}")
        print(f"           to {i.recipient}  {c['dim']}nonce {tx.nonce}{c['off']}")
        print(f"           {c['dim']}discharges {', '.join(i.obligation_ids)}"
              f"{c['off']}")
        if i.commission:
            print(f"           {c['dim']}gross {i.gross}, net of {i.commission} "
                  f"commission{c['off']}")
        for w in chk.warnings:
            print(f"           {c['warning']}note{c['off']} {w}")
        if a.verbose:
            print(f"           {c['dim']}to      {tx.to}{c['off']}")
            print(f"           {c['dim']}data    {tx.data[:50]}…{c['off']}")
            print(f"           {c['dim']}gas     {tx.gas:,} @ max "
                  f"{tx.max_fee_per_gas / 1e9:.1f} gwei{c['off']}")
        print()

    for i, chk in held:
        print(f"  {c['critical']}HELD{c['off']}     {i.reference}   "
              f"{str(i.amount):>22}")
        print(f"           to {i.recipient}")
        for b in chk.blockers:
            print(f"           {c['critical']}blocker{c['off']} {b}")
        print()

    if ready:
        sym = ready[0][0].amount.symbol
        gas = sum(tx.max_gas_cost_wei for _, tx, _ in ready)
        print(f"  {c['bold']}Total to pay{c['off']}  "
              f"{Decimal(total).scaleb(-ready[0][0].amount.decimals):,f} {sym}"
              f"   {c['dim']}max gas {Decimal(gas).scaleb(-18):.6f} ETH{c['off']}")
    print(f"\n  {c['dim']}Unsigned. Send to your signer for maker-checker "
          f"approval.{c['off']}")
    return 1 if held else 0


def main(argv: list[str] | None = None) -> int:
    # Piping into head/less closes stdout early. Restore the default SIGPIPE
    # behaviour so the process exits quietly instead of tracebacking, which is
    # what every other Unix tool does.
    try:
        import signal
        signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    except (ImportError, AttributeError, ValueError):
        pass  # Windows, or not on the main thread

    p = argparse.ArgumentParser(
        prog="python3 -m fix_settlement_recon",
        description="Reconcile FIX execution reports against on-chain settlement.",
        epilog="Exit codes: 0 clean, 1 breaks found, 2 bad input.",
    )
    p.add_argument("--fix", metavar="FILE",
                   help="file of ExecutionReports, one per line ('-' for stdin)")
    p.add_argument("--receipts", metavar="FILE",
                   help="JSON array of eth_getTransactionReceipt results")
    p.add_argument("--wallet", action="append", default=[], metavar="ACCT=0x…",
                   help="settlement wallet for an account (repeatable)")
    p.add_argument("--wallets", metavar="FILE", help="JSON object of account -> wallet")
    p.add_argument("--rpc", metavar="URL", help="JSON-RPC endpoint, to fetch receipts")
    p.add_argument("--tx", action="append", default=[], metavar="HASH",
                   help="transaction hash to fetch (repeatable, needs --rpc)")
    p.add_argument("--chain", type=int, default=1, help="chain id (default 1)")
    p.add_argument("--tolerance", type=int, default=0, metavar="MINOR",
                   help="fee tolerance in token minor units (USDC: 25000000 = 25.00)")
    p.add_argument("--window", type=float, default=2.0, metavar="DAYS",
                   help="settlement window after the fill (default 2)")
    p.add_argument("--no-final", action="store_true",
                   help="do not require finality before treating a match as settled")
    p.add_argument("--no-netting", action="store_true",
                   help="disable many-fills-to-one-transfer matching")
    p.add_argument("-v", "--verbose", action="store_true",
                   help="include what each break means and the first action")
    p.add_argument("--json", action="store_true", help="emit the full report as JSON")
    p.add_argument("--agent", action="store_true",
                   help="emit the break summary formatted for an assistant")
    p.add_argument("--instruct", action="store_true",
                   help="build same-day settlement payments from the fills "
                        "instead of reconciling")
    p.add_argument("--from-wallet", metavar="0x…", help="treasury sending wallet")
    p.add_argument("--nonce", type=int, default=0, help="starting nonce (--instruct)")
    p.add_argument("--base-fee", type=int, default=20_000_000_000, metavar="WEI",
                   help="current base fee in wei (--instruct)")
    p.add_argument("--cutoff", metavar="HH:MM",
                   help="same-day settlement cutoff in UTC, e.g. 21:00")
    p.add_argument("--runbook", action="store_true",
                   help="print the break catalogue and exit")
    p.add_argument("--demo", action="store_true",
                   help="run the built-in worked example")
    p.add_argument("--no-color", action="store_true")
    a = p.parse_args(argv)

    c = _paint(
        not a.no_color and sys.stdout.isatty() and not os.environ.get("NO_COLOR")
    )

    if a.runbook:
        for e in runbook():
            print(f"{c[e['severity']]}{e['severity'].upper():8}{c['off']} {e['code']}")
            print(f"         {e['meaning']}")
            print(f"         {c['dim']}{e['action']}{c['off']}\n")
        return 0

    if a.demo:
        payload = _demo_payload()
    else:
        if not a.fix and not a.receipts and not a.tx:
            p.print_help()
            print("\nNothing to do. Try --demo to see a worked example.", file=sys.stderr)
            return 2
        try:
            fix_text = ""
            if a.fix:
                fix_text = (sys.stdin.read() if a.fix == "-"
                            else open(a.fix, encoding="utf-8").read())
            elif not sys.stdin.isatty():
                fix_text = sys.stdin.read()

            wallets = {}
            if a.wallets:
                wallets.update(json.load(open(a.wallets, encoding="utf-8")))
            for item in a.wallet:
                if "=" not in item:
                    print(f"--wallet needs ACCOUNT=0xADDRESS, got {item!r}",
                          file=sys.stderr)
                    return 2
                k, v = item.split("=", 1)
                wallets[k.strip()] = v.strip()

            receipts, stamps, head = [], {}, None
            if a.receipts:
                receipts = json.load(open(a.receipts, encoding="utf-8"))
                if isinstance(receipts, dict):
                    receipts = [receipts]
            if a.tx:
                if not a.rpc:
                    print("--tx needs --rpc", file=sys.stderr)
                    return 2
                fetched, stamps, head = _fetch(a.rpc, a.tx, a.chain)
                receipts += fetched
        except OSError as exc:
            print(f"cannot read input: {exc}", file=sys.stderr)
            return 2
        except ValueError as exc:
            print(f"input is not valid JSON: {exc}", file=sys.stderr)
            return 2
        except Exception as exc:
            print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
            return 2

        payload = {
            "fix": fix_text, "wallets": wallets, "receipts": receipts,
            "block_timestamps": stamps, "current_block": head,
            "chain_id": a.chain,
            "config": {
                "amount_tolerance_minor": a.tolerance,
                "settlement_window_days": a.window,
                "require_final": not a.no_final,
                "enable_netting": not a.no_netting,
            },
        }

    if a.instruct:
        return _instruct(payload, a, c)

    res = run(payload)
    if not res["ok"]:
        print(res["error"], file=sys.stderr)
        return 2

    if a.json:
        print(json.dumps(res, indent=2))
    elif a.agent:
        print(res["agent_context"])
    else:
        render(res, c, a.verbose)

    return 1 if (res["counts"]["critical"] or res["counts"]["warning"]) else 0


if __name__ == "__main__":
    sys.exit(main())
