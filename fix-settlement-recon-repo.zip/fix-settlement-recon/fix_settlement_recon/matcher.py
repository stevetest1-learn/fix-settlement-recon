"""
The reconciler.

The honest problem statement: a FIX fill and an ERC-20 transfer share no
natural key. The chain has never heard of an ExecID. So matching runs in
tiers, most reliable first, and every match carries a confidence:

  1. Reference-linked. The venue embedded a settlement reference on both
     sides. Deterministic, confidence 1.0. Always prefer this — the
     engineering answer to a hard matching problem is usually to make the
     upstream system emit a key.
  2. Netted group. Several fills for one counterparty on one settlement
     date sum exactly to one transfer.
  3. One-to-one. A single fill matches a single transfer exactly.
  4. Subset. Part of a netting group explains the transfer. Bounded search,
     low confidence, always reported rather than silently accepted.

Anything left over becomes a break. Unmatched obligations and unmatched
transfers are *different* problems with different severities: a missing
payment is an operational failure, while value leaving a wallet with no
fill behind it is a security incident.
"""

from __future__ import annotations

import datetime as dt
import itertools
from collections import defaultdict
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Iterable, Sequence

from .breaks import Break, BreakCode, Severity
from .chains import get_chain, token_for_currency
from .models import (
    ChainSettlementEvent,
    SettlementObligation,
    SettlementState,
    TokenAmount,
)


@dataclass(frozen=True)
class ReconConfig:
    #: absolute tolerance in token minor units. 0 == exact match required.
    #: For USDC, 10_000 == one cent.
    amount_tolerance_minor: int = 0
    #: how long after TransactTime a settlement may legitimately land
    settlement_window: dt.timedelta = dt.timedelta(days=2)
    #: how far before TransactTime to consider (prefunded / pre-positioned legs)
    lookback_window: dt.timedelta = dt.timedelta(hours=1)
    #: allow several fills to net into one transfer
    enable_netting: bool = True
    #: cap on subset search, to keep this polynomial rather than exponential
    max_subset_size: int = 4
    max_subset_group_size: int = 12
    #: treat a residual equal to tag 12 Commission as explained
    allow_fee_residual: bool = True
    #: require FINAL before a match counts as settled
    require_final: bool = True


@dataclass
class Match:
    obligations: list[SettlementObligation]
    event: ChainSettlementEvent
    method: str
    confidence: float
    residual_minor: int = 0

    @property
    def obligation_total(self) -> int:
        return sum(o.amount.raw for o in self.obligations)


@dataclass
class ReconciliationReport:
    matches: list[Match] = field(default_factory=list)
    breaks: list[Break] = field(default_factory=list)
    unmatched_obligations: list[SettlementObligation] = field(default_factory=list)
    unmatched_events: list[ChainSettlementEvent] = field(default_factory=list)
    gas_cost_wei: int = 0
    as_of: dt.datetime = field(default_factory=lambda: dt.datetime.now(dt.timezone.utc))

    @property
    def critical(self) -> list[Break]:
        return [b for b in self.breaks if b.severity is Severity.CRITICAL]

    @property
    def is_clean(self) -> bool:
        return not any(b.severity is not Severity.INFO for b in self.breaks)

    def summary(self) -> str:
        counts: dict[str, int] = defaultdict(int)
        for b in self.breaks:
            counts[b.code.value] += 1
        lines = [
            f"Reconciliation as of {self.as_of:%Y-%m-%d %H:%M:%S}Z",
            f"  matched      : {len(self.matches)} settlement(s), "
            f"{sum(len(m.obligations) for m in self.matches)} obligation(s)",
            f"  breaks       : {len(self.breaks)} "
            f"({len(self.critical)} critical)",
            f"  unmatched    : {len(self.unmatched_obligations)} obligation(s), "
            f"{len(self.unmatched_events)} transfer(s)",
            f"  gas cost leg : {Decimal(self.gas_cost_wei).scaleb(-18):.9f} ETH "
            f"(no FIX counterpart)",
        ]
        for code, n in sorted(counts.items()):
            lines.append(f"    - {code}: {n}")
        return "\n".join(lines)

    def to_agent_context(self, max_breaks: int = 20) -> str:
        """Compact structured text for an LLM support agent to narrate.

        This is the hand-off into the Bedrock agent: the deterministic
        engine decides *what* broke, the model explains it to a human and
        drafts the counterparty mail. The model is never asked to do the
        arithmetic.
        """
        out = ["SETTLEMENT RECONCILIATION BREAKS", ""]
        for b in sorted(
            self.breaks,
            key=lambda x: {"critical": 0, "warning": 1, "info": 2}[x.severity.value],
        )[:max_breaks]:
            out.append(f"- code={b.code.value} severity={b.severity.value}")
            out.append(f"  obligations={b.obligation_ids or '[]'} events={b.event_ids or '[]'}")
            out.append(f"  detail={b.detail}")
            out.append(f"  meaning={b.meaning}")
            out.append(f"  first_action={b.action}")
            out.append("")
        if len(self.breaks) > max_breaks:
            out.append(f"({len(self.breaks) - max_breaks} further breaks truncated)")
        return "\n".join(out)


def _within_window(
    ob: SettlementObligation, ev: ChainSettlementEvent, cfg: ReconConfig
) -> bool:
    return (
        ob.transact_time - cfg.lookback_window
        <= ev.block_timestamp
        <= ob.transact_time + cfg.settlement_window
    )


def _power_of_ten_ratio(a: int, b: int) -> int | None:
    """If a/b (or b/a) is an exact power of ten, return the exponent."""
    if a == 0 or b == 0:
        return None
    hi, lo = (a, b) if a > b else (b, a)
    if hi % lo:
        return None
    q, exp = hi // lo, 0
    while q % 10 == 0:
        q //= 10
        exp += 1
    return exp if q == 1 and exp > 0 else None


def reconcile(
    obligations: Sequence[SettlementObligation],
    events: Sequence[ChainSettlementEvent],
    config: ReconConfig | None = None,
) -> ReconciliationReport:
    cfg = config or ReconConfig()
    report = ReconciliationReport()
    report.gas_cost_wei = sum(e.gas_cost_wei for e in events)

    open_obligations = list(obligations)
    live_events: list[ChainSettlementEvent] = []

    # --- pre-flight: events that can never settle anything -------------
    for ev in events:
        if ev.state is SettlementState.REVERTED:
            report.breaks.append(Break(
                code=BreakCode.TX_REVERTED,
                event_ids=[ev.event_id],
                detail=(f"tx {ev.tx_hash[:12]}… mined in block {ev.block_number} with "
                        f"status 0; gas consumed, no value moved"),
            ))
            continue
        if ev.state is SettlementState.REORGED:
            report.breaks.append(Break(
                code=BreakCode.REORGED,
                event_ids=[ev.event_id],
                detail=(f"block {ev.block_number} ({ev.block_hash[:12]}…) is no longer "
                        f"canonical"),
            ))
            continue
        live_events.append(ev)

    consumed: set[str] = set()

    def take(ev: ChainSettlementEvent) -> None:
        consumed.add(ev.event_id)

    def available() -> list[ChainSettlementEvent]:
        return [e for e in live_events if e.event_id not in consumed]

    # --- tier 1: deterministic reference link --------------------------
    by_ref: dict[str, list[ChainSettlementEvent]] = defaultdict(list)
    for ev in live_events:
        if ev.settlement_ref:
            by_ref[ev.settlement_ref].append(ev)

    still_open: list[SettlementObligation] = []
    ref_groups: dict[str, list[SettlementObligation]] = defaultdict(list)
    for ob in open_obligations:
        if ob.settlement_ref and ob.settlement_ref in by_ref:
            ref_groups[ob.settlement_ref].append(ob)
        else:
            still_open.append(ob)

    for ref, group in ref_groups.items():
        candidates = [e for e in by_ref[ref] if e.event_id not in consumed]
        if not candidates:
            still_open.extend(group)
            continue
        ev = candidates[0]
        take(ev)
        total = sum(o.amount.raw for o in group)
        report.matches.append(Match(group, ev, "reference", 1.0, ev.amount.raw - total))
    open_obligations = still_open

    # --- tier 2 & 3: netting groups, then singles ----------------------
    groups: dict[tuple, list[SettlementObligation]] = defaultdict(list)
    for ob in open_obligations:
        groups[ob.netting_key] = groups[ob.netting_key] + [ob]

    matched_ids: set[str] = set()

    for key, group in groups.items():
        chain_id, wallet, currency, _settle_date = key
        token = token_for_currency(chain_id, currency)
        symbol = token.symbol.upper() if token else currency.upper()

        candidates = [
            e for e in available()
            if e.chain_id == chain_id
            and e.recipient.lower() == wallet
            and e.token_symbol.upper() == symbol
            and any(_within_window(o, e, cfg) for o in group)
        ]
        if not candidates:
            continue

        total = sum(o.amount.raw for o in group)

        # exact group -> one transfer
        if cfg.enable_netting and len(group) > 1:
            exact = [e for e in candidates
                     if abs(e.amount.raw - total) <= cfg.amount_tolerance_minor]
            if exact:
                if len(exact) > 1:
                    report.breaks.append(Break(
                        code=BreakCode.AMBIGUOUS_MATCH,
                        obligation_ids=[o.obligation_id for o in group],
                        event_ids=[e.event_id for e in exact],
                        detail=(f"{len(exact)} transfers of {exact[0].amount} to the same "
                                f"wallet in the window; cannot attribute deterministically"),
                    ))
                ev = exact[0]
                take(ev)
                matched_ids.update(o.obligation_id for o in group)
                report.matches.append(
                    Match(list(group), ev, "netted", 0.90, ev.amount.raw - total)
                )
                continue

        # one obligation -> one transfer
        for ob in group:
            if ob.obligation_id in matched_ids:
                continue
            hits = [
                e for e in candidates
                if e.event_id not in consumed
                and abs(e.amount.raw - ob.amount.raw) <= cfg.amount_tolerance_minor
                and _within_window(ob, e, cfg)
            ]
            if not hits:
                continue
            if len(hits) > 1:
                report.breaks.append(Break(
                    code=BreakCode.AMBIGUOUS_MATCH,
                    obligation_ids=[ob.obligation_id],
                    event_ids=[e.event_id for e in hits],
                    detail=("identical amount to the same wallet in the same window; "
                            "require a venue settlement reference"),
                ))
            ev = hits[0]
            take(ev)
            matched_ids.add(ob.obligation_id)
            report.matches.append(
                Match([ob], ev, "one-to-one", 0.95, ev.amount.raw - ob.amount.raw)
            )

        # --- tier 4: bounded subset search ----------------------------
        remaining = [o for o in group if o.obligation_id not in matched_ids]
        if (
            cfg.enable_netting
            and 1 < len(remaining) <= cfg.max_subset_group_size
        ):
            for ev in [e for e in candidates if e.event_id not in consumed]:
                found = None
                for size in range(2, min(cfg.max_subset_size, len(remaining)) + 1):
                    for combo in itertools.combinations(remaining, size):
                        s = sum(o.amount.raw for o in combo)
                        if abs(s - ev.amount.raw) <= cfg.amount_tolerance_minor:
                            found = combo
                            break
                    if found:
                        break
                if found:
                    take(ev)
                    matched_ids.update(o.obligation_id for o in found)
                    report.matches.append(
                        Match(list(found), ev, "subset", 0.70,
                              ev.amount.raw - sum(o.amount.raw for o in found))
                    )
                    report.breaks.append(Break(
                        code=BreakCode.PARTIAL_NETTING,
                        obligation_ids=[o.obligation_id for o in found],
                        event_ids=[ev.event_id],
                        detail=(f"transfer explained by {len(found)} of {len(remaining)} "
                                f"open fills for this counterparty and date"),
                    ))
                    remaining = [o for o in remaining if o.obligation_id not in matched_ids]

    # --- post-match validation ----------------------------------------
    for m in report.matches:
        _validate_match(m, cfg, report)

    # --- residuals -----------------------------------------------------
    report.unmatched_obligations = [
        o for o in open_obligations if o.obligation_id not in matched_ids
    ]
    report.unmatched_events = [e for e in live_events if e.event_id not in consumed]

    _classify_unmatched(report, cfg)
    return report


def _validate_match(m: Match, cfg: ReconConfig, report: ReconciliationReport) -> None:
    ev, obs = m.event, m.obligations
    ids = [o.obligation_id for o in obs]

    if m.residual_minor != 0:
        commission_total = sum(
            o.commission.raw for o in obs if o.commission is not None
        )
        explained = (
            cfg.allow_fee_residual
            and commission_total
            and abs(m.residual_minor) == commission_total
        )
        if explained:
            report.breaks.append(Break(
                code=BreakCode.FEE_EXPLAINED_RESIDUAL,
                obligation_ids=ids, event_ids=[ev.event_id],
                detail=(f"transfer is short by {TokenAmount(commission_total, ev.amount.decimals, ev.amount.symbol)}, "
                        f"exactly the booked commission"),
            ))
        else:
            exp = _power_of_ten_ratio(m.obligation_total, ev.amount.raw)
            if exp is not None:
                report.breaks.append(Break(
                    code=BreakCode.DECIMAL_SCALE_SUSPECT,
                    obligation_ids=ids, event_ids=[ev.event_id],
                    detail=(f"instructed {m.obligation_total} vs transferred "
                            f"{ev.amount.raw} minor units — differ by exactly 10^{exp}"),
                    context={"exponent": exp, "token_decimals": ev.amount.decimals},
                ))
            else:
                report.breaks.append(Break(
                    code=BreakCode.AMOUNT_MISMATCH,
                    obligation_ids=ids, event_ids=[ev.event_id],
                    detail=(f"residual {TokenAmount(m.residual_minor, ev.amount.decimals, ev.amount.symbol)} "
                            f"unexplained by fees"),
                ))

    for o in obs:
        if o.chain_id != ev.chain_id:
            report.breaks.append(Break(
                code=BreakCode.WRONG_CHAIN,
                obligation_ids=[o.obligation_id], event_ids=[ev.event_id],
                detail=(f"instructed chain {o.chain_id} "
                        f"({get_chain(o.chain_id).name}), settled on {ev.chain_id} "
                        f"({get_chain(ev.chain_id).name})"),
            ))
        token = token_for_currency(ev.chain_id, o.fix_currency)
        if token and token.symbol.upper() != ev.token_symbol.upper():
            report.breaks.append(Break(
                code=BreakCode.WRONG_TOKEN,
                obligation_ids=[o.obligation_id], event_ids=[ev.event_id],
                detail=f"SettlCurrency {o.fix_currency} expected {token.symbol}, got {ev.token_symbol}",
            ))
        if ev.block_timestamp.date() > o.settle_date:
            report.breaks.append(Break(
                code=BreakCode.LATE_SETTLEMENT,
                obligation_ids=[o.obligation_id], event_ids=[ev.event_id],
                detail=(f"SettlDate {o.settle_date}, funds moved "
                        f"{ev.block_timestamp:%Y-%m-%d %H:%M}Z"),
            ))

    if cfg.require_final and ev.state is not SettlementState.FINAL:
        policy = get_chain(ev.chain_id).finality
        report.breaks.append(Break(
            code=BreakCode.NOT_YET_FINAL,
            obligation_ids=ids, event_ids=[ev.event_id],
            detail=(f"state={ev.state.value} at {ev.confirmations} confirmation(s); "
                    f"policy requires {policy.final_confirmations} "
                    f"({policy.model.value})"),
            context={"sequencer_trust_required": policy.sequencer_trust_required},
        ))


def _classify_unmatched(report: ReconciliationReport, cfg: ReconConfig) -> None:
    # A transfer whose amount matches an unsettled obligation but went to a
    # different wallet is the dangerous case — flag it as misdirection, not
    # as two unrelated gaps.
    for ev in report.unmatched_events:
        near = [
            o for o in report.unmatched_obligations
            if abs(o.amount.raw - ev.amount.raw) <= cfg.amount_tolerance_minor
            and o.counterparty_wallet.lower() != ev.recipient.lower()
            and _within_window(o, ev, cfg)
        ]
        if near:
            report.breaks.append(Break(
                code=BreakCode.WRONG_RECIPIENT,
                obligation_ids=[o.obligation_id for o in near],
                event_ids=[ev.event_id],
                detail=(f"{ev.amount} sent to {ev.recipient[:10]}…, but the matching "
                        f"obligation instructs {near[0].counterparty_wallet[:10]}…"),
            ))
            continue
        report.breaks.append(Break(
            code=BreakCode.NO_FIX_OBLIGATION,
            event_ids=[ev.event_id],
            detail=(f"{ev.amount} left {ev.sender[:10]}… in block {ev.block_number} "
                    f"with no fill behind it"),
        ))

    flagged = {
        oid for b in report.breaks if b.code is BreakCode.WRONG_RECIPIENT
        for oid in b.obligation_ids
    }
    for ob in report.unmatched_obligations:
        if ob.obligation_id in flagged:
            continue
        report.breaks.append(Break(
            code=BreakCode.NO_CHAIN_EVENT,
            obligation_ids=[ob.obligation_id],
            detail=(f"{ob.amount} due to {ob.counterparty_wallet[:10]}… on "
                    f"{ob.settle_date}; no matching transfer found"),
        ))
