"""
Minimal JSON-RPC client. Standard library only — no web3.py needed to run
this, though you may prefer it in production.

Isolated in its own module on purpose: nothing else in the package touches
the network, so the reconciler stays unit-testable against captured
fixtures.
"""

from __future__ import annotations

import datetime as dt
import json
import urllib.request
from typing import Any

from .chain_decode import TRANSFER_TOPIC, decode_receipt
from .models import ChainSettlementEvent


class RpcError(RuntimeError):
    pass


class JsonRpcClient:
    def __init__(self, url: str, chain_id: int, timeout: float = 20.0) -> None:
        self.url = url
        self.chain_id = chain_id
        self.timeout = timeout
        self._id = 0

    def call(self, method: str, params: list[Any] | None = None) -> Any:
        self._id += 1
        payload = json.dumps({
            "jsonrpc": "2.0", "id": self._id,
            "method": method, "params": params or [],
        }).encode()
        req = urllib.request.Request(
            self.url, data=payload, headers={"Content-Type": "application/json"}
        )
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:
            body = json.loads(resp.read())
        if "error" in body:
            raise RpcError(f"{method}: {body['error']}")
        return body["result"]

    # -- convenience ---------------------------------------------------

    def block_number(self) -> int:
        return int(self.call("eth_blockNumber"), 16)

    def finalized_block_number(self) -> int | None:
        """Consensus-layer finalized head. The correct notion of finality on
        post-Merge Ethereum — strictly better than counting confirmations."""
        try:
            blk = self.call("eth_getBlockByNumber", ["finalized", False])
        except RpcError:
            return None
        return int(blk["number"], 16) if blk else None

    def block_timestamp(self, block_number: int) -> dt.datetime:
        blk = self.call("eth_getBlockByNumber", [hex(block_number), False])
        return dt.datetime.fromtimestamp(int(blk["timestamp"], 16), dt.timezone.utc)

    def block_hash(self, block_number: int) -> str:
        blk = self.call("eth_getBlockByNumber", [hex(block_number), False])
        return blk["hash"]

    def settlement_events(self, tx_hash: str) -> list[ChainSettlementEvent]:
        """Fetch one transaction and decode its transfers into events."""
        receipt = self.call("eth_getTransactionReceipt", [tx_hash])
        if receipt is None:
            raise RpcError(f"no receipt for {tx_hash} — not mined, or wrong chain")
        tx = self.call("eth_getTransactionByHash", [tx_hash])
        if tx and "input" in tx:
            receipt = {**receipt, "input": tx["input"]}
        block_number = int(receipt["blockNumber"], 16)
        return decode_receipt(
            receipt,
            block_timestamp=self.block_timestamp(block_number),
            chain_id=self.chain_id,
            current_block=self.block_number(),
        )

    def transfers_to(
        self, token_address: str, wallet: str, from_block: int, to_block: int
    ) -> list[dict[str, Any]]:
        """eth_getLogs filtered on the indexed recipient topic.

        This is why indexed parameters matter: the node filters for you
        instead of you scanning every block.
        """
        padded = "0x" + wallet.removeprefix("0x").lower().rjust(64, "0")
        return self.call("eth_getLogs", [{
            "address": token_address,
            "fromBlock": hex(from_block),
            "toBlock": hex(to_block),
            "topics": [TRANSFER_TOPIC, None, padded],
        }])
