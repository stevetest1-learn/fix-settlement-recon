#!/usr/bin/env python3
"""
A settlement run for one business date, with the kinds of breaks that
actually show up. No network access required — everything here is
synthetic receipts in the shape the JSON-RPC node returns.

    python3 demo.py
"""

import datetime as dt

from fix_settlement_recon import (
    ReconConfig,
    StaticWalletDirectory,
    decode_receipt,
    obligations_from_messages,
    reconcile,
)
from fix_settlement_recon.keccak import event_topic

USDC = "0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48"
VENUE = "0x1111111111111111111111111111111111111111"
ACME = "0x2222222222222222222222222222222222222222"
BETA = "0x3333333333333333333333333333333333333333"
UNKNOWN = "0x4444444444444444444444444444444444444444"

TRANSFER = event_topic("Transfer(address,address,uint256)")


def pad(a):
    return "0x" + a.removeprefix("0x").rjust(64, "0")


def receipt(tx, block, legs, status="0x1"):
    # Single-leg payments carry decodable transfer() calldata. This matters for
    # reverted transactions: no log is emitted, so calldata is the only record
    # of what was attempted.
    to, amt = legs[0]
    calldata = ("0xa9059cbb"
                + to.removeprefix("0x").rjust(64, "0")
                + f"{amt:064x}") if len(legs) == 1 else "0x"
    return {
        "transactionHash": tx,
        "input": calldata,
        "blockNumber": hex(block),
        "blockHash": f"0x{block:064x}",
        "status": status,
        "from": VENUE,
        "to": USDC,
        "gasUsed": hex(52_000 + 26_000 * (len(legs) - 1)),
        "effectiveGasPrice": hex(18_000_000_000),
        "logs": [
            {
                "address": USDC,
                "topics": [TRANSFER, pad(VENUE), pad(to)],
                "data": hex(amt),
                "logIndex": hex(i),
            }
            for i, (to, amt) in enumerate(legs)
        ],
    }


def fix(exec_id, account, amount, *, commission=None, time="14:30:00.000"):
    tags = {
        35: "8", 39: "2", 17: exec_id, 37: f"ORD-{exec_id}", 11: f"CL-{exec_id}",
        1: account, 54: "1", 55: "ETH/USD", 32: "2.5", 31: "3400.00",
        119: amount, 120: "USD", 64: "20260811",
        60: f"20260811-{time}", 20002: "1",
    }
    if commission:
        tags[12] = commission
    return "\x01".join(f"{k}={v}" for k, v in tags.items())


def main():
    directory = StaticWalletDirectory()
    directory.register("ACME-FX", 1, ACME)
    directory.register("BETA-CAP", 1, BETA)

    messages = [
        # ACME: three partial fills that should net into one transfer
        fix("EX-1001", "ACME-FX", "3000.00", time="14:30:00.000"),
        fix("EX-1002", "ACME-FX", "2500.00", time="14:31:12.500"),
        fix("EX-1003", "ACME-FX", "3000.00", time="14:33:47.100"),
        # BETA: single fill, net of a 25.00 commission
        fix("EX-1004", "BETA-CAP", "12000.00", commission="25.00"),
        # BETA: a fill whose payment never went out
        fix("EX-1005", "BETA-CAP", "4750.00", time="15:02:00.000"),
        # rejected at the door: sub-cent precision cannot settle in USDC minor units
        fix("EX-1006", "ACME-FX", "100.00000015"),
    ]

    obligations, rejects = obligations_from_messages(messages, directory)
    print(f"Ingested {len(obligations)} obligation(s), {len(rejects)} rejected")
    for r in rejects:
        print(f"  REJECT: {r}")
    print()

    ts = dt.datetime(2026, 8, 11, 14, 40, tzinfo=dt.timezone.utc)
    head = 21_000_500

    receipts = [
        # netted payment to ACME, 8,500 USDC
        receipt("0xaa01", 21_000_000, [(ACME, 8_500_000_000)]),
        # batch: BETA net of commission, plus a leg to a wallet we do not know
        receipt("0xbb02", 21_000_100,
                [(BETA, 11_975_000_000), (UNKNOWN, 900_000_000)]),
        # a payment that burned gas and moved nothing
        receipt("0xcc03", 21_000_200, [(BETA, 4_750_000_000)], status="0x0"),
    ]

    events = []
    for r in receipts:
        events += decode_receipt(
            r, ts, chain_id=1, current_block=head
        )

    print(f"Decoded {len(events)} on-chain settlement event(s)")
    for e in events:
        print(f"  {e.event_id:16} {str(e.amount):>22}  -> {e.recipient[:12]}…  "
              f"{e.state.value}")
    print()

    report = reconcile(
        obligations, events,
        ReconConfig(amount_tolerance_minor=25_000_000),  # up to 25.00 USDC of fees
    )

    print(report.summary())
    print()
    print("BREAKS")
    for b in sorted(report.breaks, key=lambda x: x.severity.value):
        print(" ", b)
    print()
    print("MATCHES")
    for m in report.matches:
        ids = ",".join(o.obligation_id for o in m.obligations)
        print(f"  {m.method:11} conf={m.confidence:.2f}  {ids:28} -> {m.event.event_id}")
    print()
    print("-" * 70)
    print("HAND-OFF TO THE SUPPORT AGENT")
    print("-" * 70)
    print(report.to_agent_context(max_breaks=3))


if __name__ == "__main__":
    main()
