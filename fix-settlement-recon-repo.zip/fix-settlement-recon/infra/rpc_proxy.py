"""
Optional read-only JSON-RPC proxy.

Only needed if you want visitors to try live transaction hashes without
supplying their own endpoint. The tool works fine without it.

Design constraints, in order of importance:

  * Never expose the upstream key. It lives in Secrets Manager and is only
    ever interpolated into the outbound URL.
  * Allowlist methods. An open proxy to a paid RPC endpoint is a bill
    waiting to happen, and write methods must never be reachable.
  * Log nothing but method names. Transaction hashes are not secret, but a
    proxy that records what people are debugging is a proxy nobody at a
    bank will use.

Put this behind API Gateway with a throttle (5 req/s steady, 20 burst) and
set ``UPSTREAM_SECRET_ID`` and ``ALLOWED_ORIGIN`` in the environment.
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request

ALLOWED_METHODS = {
    "eth_blockNumber",
    "eth_getTransactionReceipt",
    "eth_getTransactionByHash",
    "eth_getBlockByNumber",
    "eth_getLogs",
}

MAX_LOG_RANGE = 5_000      # blocks; an unbounded getLogs can cost real money
MAX_BODY_BYTES = 8_192
TIMEOUT = 12.0

ALLOWED_ORIGIN = os.environ.get("ALLOWED_ORIGIN", "*")
_upstream_cache: str | None = None


def _upstream_url() -> str:
    """Resolve the upstream endpoint once per container."""
    global _upstream_cache
    if _upstream_cache:
        return _upstream_cache
    secret_id = os.environ.get("UPSTREAM_SECRET_ID")
    if secret_id:
        import boto3  # imported lazily so local tests need no AWS
        client = boto3.client("secretsmanager")
        value = client.get_secret_value(SecretId=secret_id)["SecretString"]
        try:
            _upstream_cache = json.loads(value)["rpc_url"]
        except (ValueError, KeyError):
            _upstream_cache = value
    else:
        _upstream_cache = os.environ["UPSTREAM_RPC_URL"]
    return _upstream_cache


def _reply(status: int, body: dict) -> dict:
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
            "Access-Control-Allow-Headers": "Content-Type",
            "Access-Control-Allow-Methods": "POST,OPTIONS",
            "Cache-Control": "no-store",
        },
        "body": json.dumps(body),
    }


def _rpc_error(message: str, code: int = -32600) -> dict:
    return {"jsonrpc": "2.0", "id": None, "error": {"code": code, "message": message}}


def _check(payload: dict) -> str | None:
    """Return a rejection reason, or None if the call is acceptable."""
    method = payload.get("method")
    if method not in ALLOWED_METHODS:
        return f"Method not available through this proxy: {method!r}"

    if method == "eth_getLogs":
        params = payload.get("params") or [{}]
        flt = params[0] if params else {}
        if not flt.get("address"):
            return "eth_getLogs requires an address filter."
        try:
            lo = int(str(flt.get("fromBlock", "0x0")), 16)
            hi = int(str(flt.get("toBlock", flt.get("fromBlock", "0x0"))), 16)
        except ValueError:
            return "eth_getLogs needs numeric fromBlock and toBlock."
        if hi - lo > MAX_LOG_RANGE:
            return f"Block range too wide; the limit is {MAX_LOG_RANGE:,} blocks."
    return None


def handler(event, _context=None):
    if event.get("requestContext", {}).get("http", {}).get("method") == "OPTIONS":
        return _reply(204, {})

    raw = event.get("body") or ""
    if len(raw) > MAX_BODY_BYTES:
        return _reply(413, _rpc_error("Request body too large."))

    try:
        payload = json.loads(raw)
    except ValueError:
        return _reply(400, _rpc_error("Body is not valid JSON."))
    if isinstance(payload, list):
        return _reply(400, _rpc_error("Batch requests are not supported here."))

    reason = _check(payload)
    if reason:
        print(json.dumps({"rejected": payload.get("method")}))  # method only
        return _reply(403, _rpc_error(reason, code=-32601))

    body = json.dumps({
        "jsonrpc": "2.0",
        "id": 1,
        "method": payload["method"],
        "params": payload.get("params") or [],
    }).encode()

    req = urllib.request.Request(
        _upstream_url(), data=body, headers={"Content-Type": "application/json"}
    )
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            upstream = json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        print(json.dumps({"upstream_status": exc.code, "method": payload["method"]}))
        return _reply(502, _rpc_error("Upstream node rejected the request."))
    except Exception as exc:
        print(json.dumps({"upstream_error": type(exc).__name__}))
        return _reply(504, _rpc_error("Upstream node did not respond in time."))

    print(json.dumps({"ok": payload["method"]}))
    return _reply(200, upstream)
